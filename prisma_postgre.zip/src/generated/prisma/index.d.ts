
/**
 * Client
**/

import * as runtime from './runtime/library.js';
import $Types = runtime.Types // general types
import $Public = runtime.Types.Public
import $Utils = runtime.Types.Utils
import $Extensions = runtime.Types.Extensions
import $Result = runtime.Types.Result

export type PrismaPromise<T> = $Public.PrismaPromise<T>


/**
 * Model user
 * 
 */
export type user = $Result.DefaultSelection<Prisma.$userPayload>
/**
 * Model Setting
 * 
 */
export type Setting = $Result.DefaultSelection<Prisma.$SettingPayload>
/**
 * Model EmailConfig
 * 
 */
export type EmailConfig = $Result.DefaultSelection<Prisma.$EmailConfigPayload>
/**
 * Model CloudConfig
 * 
 */
export type CloudConfig = $Result.DefaultSelection<Prisma.$CloudConfigPayload>
/**
 * Model otp
 * 
 */
export type otp = $Result.DefaultSelection<Prisma.$otpPayload>

/**
 * Enums
 */
export namespace $Enums {
  export const Role: {
  ADMIN: 'ADMIN',
  USER: 'USER'
};

export type Role = (typeof Role)[keyof typeof Role]

}

export type Role = $Enums.Role

export const Role: typeof $Enums.Role

/**
 * ##  Prisma Client ʲˢ
 *
 * Type-safe database client for TypeScript & Node.js
 * @example
 * ```
 * const prisma = new PrismaClient()
 * // Fetch zero or more Users
 * const users = await prisma.user.findMany()
 * ```
 *
 *
 * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
 */
export class PrismaClient<
  ClientOptions extends Prisma.PrismaClientOptions = Prisma.PrismaClientOptions,
  const U = 'log' extends keyof ClientOptions ? ClientOptions['log'] extends Array<Prisma.LogLevel | Prisma.LogDefinition> ? Prisma.GetEvents<ClientOptions['log']> : never : never,
  ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs
> {
  [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['other'] }

    /**
   * ##  Prisma Client ʲˢ
   *
   * Type-safe database client for TypeScript & Node.js
   * @example
   * ```
   * const prisma = new PrismaClient()
   * // Fetch zero or more Users
   * const users = await prisma.user.findMany()
   * ```
   *
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
   */

  constructor(optionsArg ?: Prisma.Subset<ClientOptions, Prisma.PrismaClientOptions>);
  $on<V extends U>(eventType: V, callback: (event: V extends 'query' ? Prisma.QueryEvent : Prisma.LogEvent) => void): PrismaClient;

  /**
   * Connect with the database
   */
  $connect(): $Utils.JsPromise<void>;

  /**
   * Disconnect from the database
   */
  $disconnect(): $Utils.JsPromise<void>;

/**
   * Executes a prepared raw query and returns the number of affected rows.
   * @example
   * ```
   * const result = await prisma.$executeRaw`UPDATE User SET cool = ${true} WHERE email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Executes a raw query and returns the number of affected rows.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$executeRawUnsafe('UPDATE User SET cool = $1 WHERE email = $2 ;', true, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Performs a prepared raw query and returns the `SELECT` data.
   * @example
   * ```
   * const result = await prisma.$queryRaw`SELECT * FROM User WHERE id = ${1} OR email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<T>;

  /**
   * Performs a raw query and returns the `SELECT` data.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$queryRawUnsafe('SELECT * FROM User WHERE id = $1 OR email = $2;', 1, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<T>;


  /**
   * Allows the running of a sequence of read/write operations that are guaranteed to either succeed or fail as a whole.
   * @example
   * ```
   * const [george, bob, alice] = await prisma.$transaction([
   *   prisma.user.create({ data: { name: 'George' } }),
   *   prisma.user.create({ data: { name: 'Bob' } }),
   *   prisma.user.create({ data: { name: 'Alice' } }),
   * ])
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/concepts/components/prisma-client/transactions).
   */
  $transaction<P extends Prisma.PrismaPromise<any>[]>(arg: [...P], options?: { isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<runtime.Types.Utils.UnwrapTuple<P>>

  $transaction<R>(fn: (prisma: Omit<PrismaClient, runtime.ITXClientDenyList>) => $Utils.JsPromise<R>, options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<R>


  $extends: $Extensions.ExtendsHook<"extends", Prisma.TypeMapCb<ClientOptions>, ExtArgs, $Utils.Call<Prisma.TypeMapCb<ClientOptions>, {
    extArgs: ExtArgs
  }>>

      /**
   * `prisma.user`: Exposes CRUD operations for the **user** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Users
    * const users = await prisma.user.findMany()
    * ```
    */
  get user(): Prisma.userDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.setting`: Exposes CRUD operations for the **Setting** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Settings
    * const settings = await prisma.setting.findMany()
    * ```
    */
  get setting(): Prisma.SettingDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.emailConfig`: Exposes CRUD operations for the **EmailConfig** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more EmailConfigs
    * const emailConfigs = await prisma.emailConfig.findMany()
    * ```
    */
  get emailConfig(): Prisma.EmailConfigDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.cloudConfig`: Exposes CRUD operations for the **CloudConfig** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more CloudConfigs
    * const cloudConfigs = await prisma.cloudConfig.findMany()
    * ```
    */
  get cloudConfig(): Prisma.CloudConfigDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.otp`: Exposes CRUD operations for the **otp** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Otps
    * const otps = await prisma.otp.findMany()
    * ```
    */
  get otp(): Prisma.otpDelegate<ExtArgs, ClientOptions>;
}

export namespace Prisma {
  export import DMMF = runtime.DMMF

  export type PrismaPromise<T> = $Public.PrismaPromise<T>

  /**
   * Validator
   */
  export import validator = runtime.Public.validator

  /**
   * Prisma Errors
   */
  export import PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError
  export import PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError
  export import PrismaClientRustPanicError = runtime.PrismaClientRustPanicError
  export import PrismaClientInitializationError = runtime.PrismaClientInitializationError
  export import PrismaClientValidationError = runtime.PrismaClientValidationError

  /**
   * Re-export of sql-template-tag
   */
  export import sql = runtime.sqltag
  export import empty = runtime.empty
  export import join = runtime.join
  export import raw = runtime.raw
  export import Sql = runtime.Sql



  /**
   * Decimal.js
   */
  export import Decimal = runtime.Decimal

  export type DecimalJsLike = runtime.DecimalJsLike

  /**
   * Metrics
   */
  export type Metrics = runtime.Metrics
  export type Metric<T> = runtime.Metric<T>
  export type MetricHistogram = runtime.MetricHistogram
  export type MetricHistogramBucket = runtime.MetricHistogramBucket

  /**
  * Extensions
  */
  export import Extension = $Extensions.UserArgs
  export import getExtensionContext = runtime.Extensions.getExtensionContext
  export import Args = $Public.Args
  export import Payload = $Public.Payload
  export import Result = $Public.Result
  export import Exact = $Public.Exact

  /**
   * Prisma Client JS version: 6.17.1
   * Query Engine version: 272a37d34178c2894197e17273bf937f25acdeac
   */
  export type PrismaVersion = {
    client: string
  }

  export const prismaVersion: PrismaVersion

  /**
   * Utility Types
   */


  export import JsonObject = runtime.JsonObject
  export import JsonArray = runtime.JsonArray
  export import JsonValue = runtime.JsonValue
  export import InputJsonObject = runtime.InputJsonObject
  export import InputJsonArray = runtime.InputJsonArray
  export import InputJsonValue = runtime.InputJsonValue

  /**
   * Types of the values used to represent different kinds of `null` values when working with JSON fields.
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  namespace NullTypes {
    /**
    * Type of `Prisma.DbNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.DbNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class DbNull {
      private DbNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.JsonNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.JsonNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class JsonNull {
      private JsonNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.AnyNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.AnyNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class AnyNull {
      private AnyNull: never
      private constructor()
    }
  }

  /**
   * Helper for filtering JSON entries that have `null` on the database (empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const DbNull: NullTypes.DbNull

  /**
   * Helper for filtering JSON entries that have JSON `null` values (not empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const JsonNull: NullTypes.JsonNull

  /**
   * Helper for filtering JSON entries that are `Prisma.DbNull` or `Prisma.JsonNull`
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const AnyNull: NullTypes.AnyNull

  type SelectAndInclude = {
    select: any
    include: any
  }

  type SelectAndOmit = {
    select: any
    omit: any
  }

  /**
   * Get the type of the value, that the Promise holds.
   */
  export type PromiseType<T extends PromiseLike<any>> = T extends PromiseLike<infer U> ? U : T;

  /**
   * Get the return type of a function which returns a Promise.
   */
  export type PromiseReturnType<T extends (...args: any) => $Utils.JsPromise<any>> = PromiseType<ReturnType<T>>

  /**
   * From T, pick a set of properties whose keys are in the union K
   */
  type Prisma__Pick<T, K extends keyof T> = {
      [P in K]: T[P];
  };


  export type Enumerable<T> = T | Array<T>;

  export type RequiredKeys<T> = {
    [K in keyof T]-?: {} extends Prisma__Pick<T, K> ? never : K
  }[keyof T]

  export type TruthyKeys<T> = keyof {
    [K in keyof T as T[K] extends false | undefined | null ? never : K]: K
  }

  export type TrueKeys<T> = TruthyKeys<Prisma__Pick<T, RequiredKeys<T>>>

  /**
   * Subset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection
   */
  export type Subset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
  };

  /**
   * SelectSubset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection.
   * Additionally, it validates, if both select and include are present. If the case, it errors.
   */
  export type SelectSubset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    (T extends SelectAndInclude
      ? 'Please either choose `select` or `include`.'
      : T extends SelectAndOmit
        ? 'Please either choose `select` or `omit`.'
        : {})

  /**
   * Subset + Intersection
   * @desc From `T` pick properties that exist in `U` and intersect `K`
   */
  export type SubsetIntersection<T, U, K> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    K

  type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

  /**
   * XOR is needed to have a real mutually exclusive union type
   * https://stackoverflow.com/questions/42123407/does-typescript-support-mutually-exclusive-types
   */
  type XOR<T, U> =
    T extends object ?
    U extends object ?
      (Without<T, U> & U) | (Without<U, T> & T)
    : U : T


  /**
   * Is T a Record?
   */
  type IsObject<T extends any> = T extends Array<any>
  ? False
  : T extends Date
  ? False
  : T extends Uint8Array
  ? False
  : T extends BigInt
  ? False
  : T extends object
  ? True
  : False


  /**
   * If it's T[], return T
   */
  export type UnEnumerate<T extends unknown> = T extends Array<infer U> ? U : T

  /**
   * From ts-toolbelt
   */

  type __Either<O extends object, K extends Key> = Omit<O, K> &
    {
      // Merge all but K
      [P in K]: Prisma__Pick<O, P & keyof O> // With K possibilities
    }[K]

  type EitherStrict<O extends object, K extends Key> = Strict<__Either<O, K>>

  type EitherLoose<O extends object, K extends Key> = ComputeRaw<__Either<O, K>>

  type _Either<
    O extends object,
    K extends Key,
    strict extends Boolean
  > = {
    1: EitherStrict<O, K>
    0: EitherLoose<O, K>
  }[strict]

  type Either<
    O extends object,
    K extends Key,
    strict extends Boolean = 1
  > = O extends unknown ? _Either<O, K, strict> : never

  export type Union = any

  type PatchUndefined<O extends object, O1 extends object> = {
    [K in keyof O]: O[K] extends undefined ? At<O1, K> : O[K]
  } & {}

  /** Helper Types for "Merge" **/
  export type IntersectOf<U extends Union> = (
    U extends unknown ? (k: U) => void : never
  ) extends (k: infer I) => void
    ? I
    : never

  export type Overwrite<O extends object, O1 extends object> = {
      [K in keyof O]: K extends keyof O1 ? O1[K] : O[K];
  } & {};

  type _Merge<U extends object> = IntersectOf<Overwrite<U, {
      [K in keyof U]-?: At<U, K>;
  }>>;

  type Key = string | number | symbol;
  type AtBasic<O extends object, K extends Key> = K extends keyof O ? O[K] : never;
  type AtStrict<O extends object, K extends Key> = O[K & keyof O];
  type AtLoose<O extends object, K extends Key> = O extends unknown ? AtStrict<O, K> : never;
  export type At<O extends object, K extends Key, strict extends Boolean = 1> = {
      1: AtStrict<O, K>;
      0: AtLoose<O, K>;
  }[strict];

  export type ComputeRaw<A extends any> = A extends Function ? A : {
    [K in keyof A]: A[K];
  } & {};

  export type OptionalFlat<O> = {
    [K in keyof O]?: O[K];
  } & {};

  type _Record<K extends keyof any, T> = {
    [P in K]: T;
  };

  // cause typescript not to expand types and preserve names
  type NoExpand<T> = T extends unknown ? T : never;

  // this type assumes the passed object is entirely optional
  type AtLeast<O extends object, K extends string> = NoExpand<
    O extends unknown
    ? | (K extends keyof O ? { [P in K]: O[P] } & O : O)
      | {[P in keyof O as P extends K ? P : never]-?: O[P]} & O
    : never>;

  type _Strict<U, _U = U> = U extends unknown ? U & OptionalFlat<_Record<Exclude<Keys<_U>, keyof U>, never>> : never;

  export type Strict<U extends object> = ComputeRaw<_Strict<U>>;
  /** End Helper Types for "Merge" **/

  export type Merge<U extends object> = ComputeRaw<_Merge<Strict<U>>>;

  /**
  A [[Boolean]]
  */
  export type Boolean = True | False

  // /**
  // 1
  // */
  export type True = 1

  /**
  0
  */
  export type False = 0

  export type Not<B extends Boolean> = {
    0: 1
    1: 0
  }[B]

  export type Extends<A1 extends any, A2 extends any> = [A1] extends [never]
    ? 0 // anything `never` is false
    : A1 extends A2
    ? 1
    : 0

  export type Has<U extends Union, U1 extends Union> = Not<
    Extends<Exclude<U1, U>, U1>
  >

  export type Or<B1 extends Boolean, B2 extends Boolean> = {
    0: {
      0: 0
      1: 1
    }
    1: {
      0: 1
      1: 1
    }
  }[B1][B2]

  export type Keys<U extends Union> = U extends unknown ? keyof U : never

  type Cast<A, B> = A extends B ? A : B;

  export const type: unique symbol;



  /**
   * Used by group by
   */

  export type GetScalarType<T, O> = O extends object ? {
    [P in keyof T]: P extends keyof O
      ? O[P]
      : never
  } : never

  type FieldPaths<
    T,
    U = Omit<T, '_avg' | '_sum' | '_count' | '_min' | '_max'>
  > = IsObject<T> extends True ? U : T

  type GetHavingFields<T> = {
    [K in keyof T]: Or<
      Or<Extends<'OR', K>, Extends<'AND', K>>,
      Extends<'NOT', K>
    > extends True
      ? // infer is only needed to not hit TS limit
        // based on the brilliant idea of Pierre-Antoine Mills
        // https://github.com/microsoft/TypeScript/issues/30188#issuecomment-478938437
        T[K] extends infer TK
        ? GetHavingFields<UnEnumerate<TK> extends object ? Merge<UnEnumerate<TK>> : never>
        : never
      : {} extends FieldPaths<T[K]>
      ? never
      : K
  }[keyof T]

  /**
   * Convert tuple to union
   */
  type _TupleToUnion<T> = T extends (infer E)[] ? E : never
  type TupleToUnion<K extends readonly any[]> = _TupleToUnion<K>
  type MaybeTupleToUnion<T> = T extends any[] ? TupleToUnion<T> : T

  /**
   * Like `Pick`, but additionally can also accept an array of keys
   */
  type PickEnumerable<T, K extends Enumerable<keyof T> | keyof T> = Prisma__Pick<T, MaybeTupleToUnion<K>>

  /**
   * Exclude all keys with underscores
   */
  type ExcludeUnderscoreKeys<T extends string> = T extends `_${string}` ? never : T


  export type FieldRef<Model, FieldType> = runtime.FieldRef<Model, FieldType>

  type FieldRefInputType<Model, FieldType> = Model extends never ? never : FieldRef<Model, FieldType>


  export const ModelName: {
    user: 'user',
    Setting: 'Setting',
    EmailConfig: 'EmailConfig',
    CloudConfig: 'CloudConfig',
    otp: 'otp'
  };

  export type ModelName = (typeof ModelName)[keyof typeof ModelName]


  export type Datasources = {
    db?: Datasource
  }

  interface TypeMapCb<ClientOptions = {}> extends $Utils.Fn<{extArgs: $Extensions.InternalArgs }, $Utils.Record<string, any>> {
    returns: Prisma.TypeMap<this['params']['extArgs'], ClientOptions extends { omit: infer OmitOptions } ? OmitOptions : {}>
  }

  export type TypeMap<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> = {
    globalOmitOptions: {
      omit: GlobalOmitOptions
    }
    meta: {
      modelProps: "user" | "setting" | "emailConfig" | "cloudConfig" | "otp"
      txIsolationLevel: Prisma.TransactionIsolationLevel
    }
    model: {
      user: {
        payload: Prisma.$userPayload<ExtArgs>
        fields: Prisma.userFieldRefs
        operations: {
          findUnique: {
            args: Prisma.userFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$userPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.userFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$userPayload>
          }
          findFirst: {
            args: Prisma.userFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$userPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.userFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$userPayload>
          }
          findMany: {
            args: Prisma.userFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$userPayload>[]
          }
          create: {
            args: Prisma.userCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$userPayload>
          }
          createMany: {
            args: Prisma.userCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.userCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$userPayload>[]
          }
          delete: {
            args: Prisma.userDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$userPayload>
          }
          update: {
            args: Prisma.userUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$userPayload>
          }
          deleteMany: {
            args: Prisma.userDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.userUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.userUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$userPayload>[]
          }
          upsert: {
            args: Prisma.userUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$userPayload>
          }
          aggregate: {
            args: Prisma.UserAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateUser>
          }
          groupBy: {
            args: Prisma.userGroupByArgs<ExtArgs>
            result: $Utils.Optional<UserGroupByOutputType>[]
          }
          count: {
            args: Prisma.userCountArgs<ExtArgs>
            result: $Utils.Optional<UserCountAggregateOutputType> | number
          }
        }
      }
      Setting: {
        payload: Prisma.$SettingPayload<ExtArgs>
        fields: Prisma.SettingFieldRefs
        operations: {
          findUnique: {
            args: Prisma.SettingFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SettingPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.SettingFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SettingPayload>
          }
          findFirst: {
            args: Prisma.SettingFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SettingPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.SettingFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SettingPayload>
          }
          findMany: {
            args: Prisma.SettingFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SettingPayload>[]
          }
          create: {
            args: Prisma.SettingCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SettingPayload>
          }
          createMany: {
            args: Prisma.SettingCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.SettingCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SettingPayload>[]
          }
          delete: {
            args: Prisma.SettingDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SettingPayload>
          }
          update: {
            args: Prisma.SettingUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SettingPayload>
          }
          deleteMany: {
            args: Prisma.SettingDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.SettingUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.SettingUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SettingPayload>[]
          }
          upsert: {
            args: Prisma.SettingUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SettingPayload>
          }
          aggregate: {
            args: Prisma.SettingAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateSetting>
          }
          groupBy: {
            args: Prisma.SettingGroupByArgs<ExtArgs>
            result: $Utils.Optional<SettingGroupByOutputType>[]
          }
          count: {
            args: Prisma.SettingCountArgs<ExtArgs>
            result: $Utils.Optional<SettingCountAggregateOutputType> | number
          }
        }
      }
      EmailConfig: {
        payload: Prisma.$EmailConfigPayload<ExtArgs>
        fields: Prisma.EmailConfigFieldRefs
        operations: {
          findUnique: {
            args: Prisma.EmailConfigFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EmailConfigPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.EmailConfigFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EmailConfigPayload>
          }
          findFirst: {
            args: Prisma.EmailConfigFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EmailConfigPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.EmailConfigFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EmailConfigPayload>
          }
          findMany: {
            args: Prisma.EmailConfigFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EmailConfigPayload>[]
          }
          create: {
            args: Prisma.EmailConfigCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EmailConfigPayload>
          }
          createMany: {
            args: Prisma.EmailConfigCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.EmailConfigCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EmailConfigPayload>[]
          }
          delete: {
            args: Prisma.EmailConfigDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EmailConfigPayload>
          }
          update: {
            args: Prisma.EmailConfigUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EmailConfigPayload>
          }
          deleteMany: {
            args: Prisma.EmailConfigDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.EmailConfigUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.EmailConfigUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EmailConfigPayload>[]
          }
          upsert: {
            args: Prisma.EmailConfigUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$EmailConfigPayload>
          }
          aggregate: {
            args: Prisma.EmailConfigAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateEmailConfig>
          }
          groupBy: {
            args: Prisma.EmailConfigGroupByArgs<ExtArgs>
            result: $Utils.Optional<EmailConfigGroupByOutputType>[]
          }
          count: {
            args: Prisma.EmailConfigCountArgs<ExtArgs>
            result: $Utils.Optional<EmailConfigCountAggregateOutputType> | number
          }
        }
      }
      CloudConfig: {
        payload: Prisma.$CloudConfigPayload<ExtArgs>
        fields: Prisma.CloudConfigFieldRefs
        operations: {
          findUnique: {
            args: Prisma.CloudConfigFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CloudConfigPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.CloudConfigFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CloudConfigPayload>
          }
          findFirst: {
            args: Prisma.CloudConfigFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CloudConfigPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.CloudConfigFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CloudConfigPayload>
          }
          findMany: {
            args: Prisma.CloudConfigFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CloudConfigPayload>[]
          }
          create: {
            args: Prisma.CloudConfigCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CloudConfigPayload>
          }
          createMany: {
            args: Prisma.CloudConfigCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.CloudConfigCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CloudConfigPayload>[]
          }
          delete: {
            args: Prisma.CloudConfigDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CloudConfigPayload>
          }
          update: {
            args: Prisma.CloudConfigUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CloudConfigPayload>
          }
          deleteMany: {
            args: Prisma.CloudConfigDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.CloudConfigUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.CloudConfigUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CloudConfigPayload>[]
          }
          upsert: {
            args: Prisma.CloudConfigUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$CloudConfigPayload>
          }
          aggregate: {
            args: Prisma.CloudConfigAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateCloudConfig>
          }
          groupBy: {
            args: Prisma.CloudConfigGroupByArgs<ExtArgs>
            result: $Utils.Optional<CloudConfigGroupByOutputType>[]
          }
          count: {
            args: Prisma.CloudConfigCountArgs<ExtArgs>
            result: $Utils.Optional<CloudConfigCountAggregateOutputType> | number
          }
        }
      }
      otp: {
        payload: Prisma.$otpPayload<ExtArgs>
        fields: Prisma.otpFieldRefs
        operations: {
          findUnique: {
            args: Prisma.otpFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$otpPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.otpFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$otpPayload>
          }
          findFirst: {
            args: Prisma.otpFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$otpPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.otpFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$otpPayload>
          }
          findMany: {
            args: Prisma.otpFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$otpPayload>[]
          }
          create: {
            args: Prisma.otpCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$otpPayload>
          }
          createMany: {
            args: Prisma.otpCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.otpCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$otpPayload>[]
          }
          delete: {
            args: Prisma.otpDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$otpPayload>
          }
          update: {
            args: Prisma.otpUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$otpPayload>
          }
          deleteMany: {
            args: Prisma.otpDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.otpUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.otpUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$otpPayload>[]
          }
          upsert: {
            args: Prisma.otpUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$otpPayload>
          }
          aggregate: {
            args: Prisma.OtpAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateOtp>
          }
          groupBy: {
            args: Prisma.otpGroupByArgs<ExtArgs>
            result: $Utils.Optional<OtpGroupByOutputType>[]
          }
          count: {
            args: Prisma.otpCountArgs<ExtArgs>
            result: $Utils.Optional<OtpCountAggregateOutputType> | number
          }
        }
      }
    }
  } & {
    other: {
      payload: any
      operations: {
        $executeRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $executeRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
        $queryRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $queryRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
      }
    }
  }
  export const defineExtension: $Extensions.ExtendsHook<"define", Prisma.TypeMapCb, $Extensions.DefaultArgs>
  export type DefaultPrismaClient = PrismaClient
  export type ErrorFormat = 'pretty' | 'colorless' | 'minimal'
  export interface PrismaClientOptions {
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasources?: Datasources
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasourceUrl?: string
    /**
     * @default "colorless"
     */
    errorFormat?: ErrorFormat
    /**
     * @example
     * ```
     * // Shorthand for `emit: 'stdout'`
     * log: ['query', 'info', 'warn', 'error']
     * 
     * // Emit as events only
     * log: [
     *   { emit: 'event', level: 'query' },
     *   { emit: 'event', level: 'info' },
     *   { emit: 'event', level: 'warn' }
     *   { emit: 'event', level: 'error' }
     * ]
     * 
     * / Emit as events and log to stdout
     * og: [
     *  { emit: 'stdout', level: 'query' },
     *  { emit: 'stdout', level: 'info' },
     *  { emit: 'stdout', level: 'warn' }
     *  { emit: 'stdout', level: 'error' }
     * 
     * ```
     * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/logging#the-log-option).
     */
    log?: (LogLevel | LogDefinition)[]
    /**
     * The default values for transactionOptions
     * maxWait ?= 2000
     * timeout ?= 5000
     */
    transactionOptions?: {
      maxWait?: number
      timeout?: number
      isolationLevel?: Prisma.TransactionIsolationLevel
    }
    /**
     * Instance of a Driver Adapter, e.g., like one provided by `@prisma/adapter-planetscale`
     */
    adapter?: runtime.SqlDriverAdapterFactory | null
    /**
     * Global configuration for omitting model fields by default.
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   omit: {
     *     user: {
     *       password: true
     *     }
     *   }
     * })
     * ```
     */
    omit?: Prisma.GlobalOmitConfig
  }
  export type GlobalOmitConfig = {
    user?: userOmit
    setting?: SettingOmit
    emailConfig?: EmailConfigOmit
    cloudConfig?: CloudConfigOmit
    otp?: otpOmit
  }

  /* Types for Logging */
  export type LogLevel = 'info' | 'query' | 'warn' | 'error'
  export type LogDefinition = {
    level: LogLevel
    emit: 'stdout' | 'event'
  }

  export type CheckIsLogLevel<T> = T extends LogLevel ? T : never;

  export type GetLogType<T> = CheckIsLogLevel<
    T extends LogDefinition ? T['level'] : T
  >;

  export type GetEvents<T extends any[]> = T extends Array<LogLevel | LogDefinition>
    ? GetLogType<T[number]>
    : never;

  export type QueryEvent = {
    timestamp: Date
    query: string
    params: string
    duration: number
    target: string
  }

  export type LogEvent = {
    timestamp: Date
    message: string
    target: string
  }
  /* End Types for Logging */


  export type PrismaAction =
    | 'findUnique'
    | 'findUniqueOrThrow'
    | 'findMany'
    | 'findFirst'
    | 'findFirstOrThrow'
    | 'create'
    | 'createMany'
    | 'createManyAndReturn'
    | 'update'
    | 'updateMany'
    | 'updateManyAndReturn'
    | 'upsert'
    | 'delete'
    | 'deleteMany'
    | 'executeRaw'
    | 'queryRaw'
    | 'aggregate'
    | 'count'
    | 'runCommandRaw'
    | 'findRaw'
    | 'groupBy'

  // tested in getLogLevel.test.ts
  export function getLogLevel(log: Array<LogLevel | LogDefinition>): LogLevel | undefined;

  /**
   * `PrismaClient` proxy available in interactive transactions.
   */
  export type TransactionClient = Omit<Prisma.DefaultPrismaClient, runtime.ITXClientDenyList>

  export type Datasource = {
    url?: string
  }

  /**
   * Count Types
   */



  /**
   * Models
   */

  /**
   * Model user
   */

  export type AggregateUser = {
    _count: UserCountAggregateOutputType | null
    _min: UserMinAggregateOutputType | null
    _max: UserMaxAggregateOutputType | null
  }

  export type UserMinAggregateOutputType = {
    id: string | null
    name: string | null
    email: string | null
    password: string | null
    image: string | null
    phone: string | null
    role: $Enums.Role | null
    country: string | null
    city: string | null
    state: string | null
    zip_code: string | null
    address: string | null
    about: string | null
    is_deleted: boolean | null
    otp: string | null
  }

  export type UserMaxAggregateOutputType = {
    id: string | null
    name: string | null
    email: string | null
    password: string | null
    image: string | null
    phone: string | null
    role: $Enums.Role | null
    country: string | null
    city: string | null
    state: string | null
    zip_code: string | null
    address: string | null
    about: string | null
    is_deleted: boolean | null
    otp: string | null
  }

  export type UserCountAggregateOutputType = {
    id: number
    name: number
    email: number
    password: number
    image: number
    phone: number
    role: number
    country: number
    city: number
    state: number
    zip_code: number
    address: number
    about: number
    is_deleted: number
    otp: number
    _all: number
  }


  export type UserMinAggregateInputType = {
    id?: true
    name?: true
    email?: true
    password?: true
    image?: true
    phone?: true
    role?: true
    country?: true
    city?: true
    state?: true
    zip_code?: true
    address?: true
    about?: true
    is_deleted?: true
    otp?: true
  }

  export type UserMaxAggregateInputType = {
    id?: true
    name?: true
    email?: true
    password?: true
    image?: true
    phone?: true
    role?: true
    country?: true
    city?: true
    state?: true
    zip_code?: true
    address?: true
    about?: true
    is_deleted?: true
    otp?: true
  }

  export type UserCountAggregateInputType = {
    id?: true
    name?: true
    email?: true
    password?: true
    image?: true
    phone?: true
    role?: true
    country?: true
    city?: true
    state?: true
    zip_code?: true
    address?: true
    about?: true
    is_deleted?: true
    otp?: true
    _all?: true
  }

  export type UserAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which user to aggregate.
     */
    where?: userWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of users to fetch.
     */
    orderBy?: userOrderByWithRelationInput | userOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: userWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned users
    **/
    _count?: true | UserCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: UserMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: UserMaxAggregateInputType
  }

  export type GetUserAggregateType<T extends UserAggregateArgs> = {
        [P in keyof T & keyof AggregateUser]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateUser[P]>
      : GetScalarType<T[P], AggregateUser[P]>
  }




  export type userGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: userWhereInput
    orderBy?: userOrderByWithAggregationInput | userOrderByWithAggregationInput[]
    by: UserScalarFieldEnum[] | UserScalarFieldEnum
    having?: userScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: UserCountAggregateInputType | true
    _min?: UserMinAggregateInputType
    _max?: UserMaxAggregateInputType
  }

  export type UserGroupByOutputType = {
    id: string
    name: string | null
    email: string
    password: string
    image: string | null
    phone: string | null
    role: $Enums.Role
    country: string | null
    city: string | null
    state: string | null
    zip_code: string | null
    address: string | null
    about: string | null
    is_deleted: boolean | null
    otp: string
    _count: UserCountAggregateOutputType | null
    _min: UserMinAggregateOutputType | null
    _max: UserMaxAggregateOutputType | null
  }

  type GetUserGroupByPayload<T extends userGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<UserGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof UserGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], UserGroupByOutputType[P]>
            : GetScalarType<T[P], UserGroupByOutputType[P]>
        }
      >
    >


  export type userSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    email?: boolean
    password?: boolean
    image?: boolean
    phone?: boolean
    role?: boolean
    country?: boolean
    city?: boolean
    state?: boolean
    zip_code?: boolean
    address?: boolean
    about?: boolean
    is_deleted?: boolean
    otp?: boolean
  }, ExtArgs["result"]["user"]>

  export type userSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    email?: boolean
    password?: boolean
    image?: boolean
    phone?: boolean
    role?: boolean
    country?: boolean
    city?: boolean
    state?: boolean
    zip_code?: boolean
    address?: boolean
    about?: boolean
    is_deleted?: boolean
    otp?: boolean
  }, ExtArgs["result"]["user"]>

  export type userSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    email?: boolean
    password?: boolean
    image?: boolean
    phone?: boolean
    role?: boolean
    country?: boolean
    city?: boolean
    state?: boolean
    zip_code?: boolean
    address?: boolean
    about?: boolean
    is_deleted?: boolean
    otp?: boolean
  }, ExtArgs["result"]["user"]>

  export type userSelectScalar = {
    id?: boolean
    name?: boolean
    email?: boolean
    password?: boolean
    image?: boolean
    phone?: boolean
    role?: boolean
    country?: boolean
    city?: boolean
    state?: boolean
    zip_code?: boolean
    address?: boolean
    about?: boolean
    is_deleted?: boolean
    otp?: boolean
  }

  export type userOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "email" | "password" | "image" | "phone" | "role" | "country" | "city" | "state" | "zip_code" | "address" | "about" | "is_deleted" | "otp", ExtArgs["result"]["user"]>

  export type $userPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "user"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: string
      name: string | null
      email: string
      password: string
      image: string | null
      phone: string | null
      role: $Enums.Role
      country: string | null
      city: string | null
      state: string | null
      zip_code: string | null
      address: string | null
      about: string | null
      is_deleted: boolean | null
      otp: string
    }, ExtArgs["result"]["user"]>
    composites: {}
  }

  type userGetPayload<S extends boolean | null | undefined | userDefaultArgs> = $Result.GetResult<Prisma.$userPayload, S>

  type userCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<userFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: UserCountAggregateInputType | true
    }

  export interface userDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['user'], meta: { name: 'user' } }
    /**
     * Find zero or one User that matches the filter.
     * @param {userFindUniqueArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends userFindUniqueArgs>(args: SelectSubset<T, userFindUniqueArgs<ExtArgs>>): Prisma__userClient<$Result.GetResult<Prisma.$userPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one User that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {userFindUniqueOrThrowArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends userFindUniqueOrThrowArgs>(args: SelectSubset<T, userFindUniqueOrThrowArgs<ExtArgs>>): Prisma__userClient<$Result.GetResult<Prisma.$userPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first User that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {userFindFirstArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends userFindFirstArgs>(args?: SelectSubset<T, userFindFirstArgs<ExtArgs>>): Prisma__userClient<$Result.GetResult<Prisma.$userPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first User that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {userFindFirstOrThrowArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends userFindFirstOrThrowArgs>(args?: SelectSubset<T, userFindFirstOrThrowArgs<ExtArgs>>): Prisma__userClient<$Result.GetResult<Prisma.$userPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Users that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {userFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Users
     * const users = await prisma.user.findMany()
     * 
     * // Get first 10 Users
     * const users = await prisma.user.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const userWithIdOnly = await prisma.user.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends userFindManyArgs>(args?: SelectSubset<T, userFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$userPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a User.
     * @param {userCreateArgs} args - Arguments to create a User.
     * @example
     * // Create one User
     * const User = await prisma.user.create({
     *   data: {
     *     // ... data to create a User
     *   }
     * })
     * 
     */
    create<T extends userCreateArgs>(args: SelectSubset<T, userCreateArgs<ExtArgs>>): Prisma__userClient<$Result.GetResult<Prisma.$userPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Users.
     * @param {userCreateManyArgs} args - Arguments to create many Users.
     * @example
     * // Create many Users
     * const user = await prisma.user.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends userCreateManyArgs>(args?: SelectSubset<T, userCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Users and returns the data saved in the database.
     * @param {userCreateManyAndReturnArgs} args - Arguments to create many Users.
     * @example
     * // Create many Users
     * const user = await prisma.user.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Users and only return the `id`
     * const userWithIdOnly = await prisma.user.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends userCreateManyAndReturnArgs>(args?: SelectSubset<T, userCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$userPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a User.
     * @param {userDeleteArgs} args - Arguments to delete one User.
     * @example
     * // Delete one User
     * const User = await prisma.user.delete({
     *   where: {
     *     // ... filter to delete one User
     *   }
     * })
     * 
     */
    delete<T extends userDeleteArgs>(args: SelectSubset<T, userDeleteArgs<ExtArgs>>): Prisma__userClient<$Result.GetResult<Prisma.$userPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one User.
     * @param {userUpdateArgs} args - Arguments to update one User.
     * @example
     * // Update one User
     * const user = await prisma.user.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends userUpdateArgs>(args: SelectSubset<T, userUpdateArgs<ExtArgs>>): Prisma__userClient<$Result.GetResult<Prisma.$userPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Users.
     * @param {userDeleteManyArgs} args - Arguments to filter Users to delete.
     * @example
     * // Delete a few Users
     * const { count } = await prisma.user.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends userDeleteManyArgs>(args?: SelectSubset<T, userDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {userUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Users
     * const user = await prisma.user.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends userUpdateManyArgs>(args: SelectSubset<T, userUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Users and returns the data updated in the database.
     * @param {userUpdateManyAndReturnArgs} args - Arguments to update many Users.
     * @example
     * // Update many Users
     * const user = await prisma.user.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Users and only return the `id`
     * const userWithIdOnly = await prisma.user.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends userUpdateManyAndReturnArgs>(args: SelectSubset<T, userUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$userPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one User.
     * @param {userUpsertArgs} args - Arguments to update or create a User.
     * @example
     * // Update or create a User
     * const user = await prisma.user.upsert({
     *   create: {
     *     // ... data to create a User
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the User we want to update
     *   }
     * })
     */
    upsert<T extends userUpsertArgs>(args: SelectSubset<T, userUpsertArgs<ExtArgs>>): Prisma__userClient<$Result.GetResult<Prisma.$userPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {userCountArgs} args - Arguments to filter Users to count.
     * @example
     * // Count the number of Users
     * const count = await prisma.user.count({
     *   where: {
     *     // ... the filter for the Users we want to count
     *   }
     * })
    **/
    count<T extends userCountArgs>(
      args?: Subset<T, userCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], UserCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a User.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends UserAggregateArgs>(args: Subset<T, UserAggregateArgs>): Prisma.PrismaPromise<GetUserAggregateType<T>>

    /**
     * Group by User.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {userGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends userGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: userGroupByArgs['orderBy'] }
        : { orderBy?: userGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, userGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetUserGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the user model
   */
  readonly fields: userFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for user.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__userClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the user model
   */
  interface userFieldRefs {
    readonly id: FieldRef<"user", 'String'>
    readonly name: FieldRef<"user", 'String'>
    readonly email: FieldRef<"user", 'String'>
    readonly password: FieldRef<"user", 'String'>
    readonly image: FieldRef<"user", 'String'>
    readonly phone: FieldRef<"user", 'String'>
    readonly role: FieldRef<"user", 'Role'>
    readonly country: FieldRef<"user", 'String'>
    readonly city: FieldRef<"user", 'String'>
    readonly state: FieldRef<"user", 'String'>
    readonly zip_code: FieldRef<"user", 'String'>
    readonly address: FieldRef<"user", 'String'>
    readonly about: FieldRef<"user", 'String'>
    readonly is_deleted: FieldRef<"user", 'Boolean'>
    readonly otp: FieldRef<"user", 'String'>
  }
    

  // Custom InputTypes
  /**
   * user findUnique
   */
  export type userFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user
     */
    select?: userSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user
     */
    omit?: userOmit<ExtArgs> | null
    /**
     * Filter, which user to fetch.
     */
    where: userWhereUniqueInput
  }

  /**
   * user findUniqueOrThrow
   */
  export type userFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user
     */
    select?: userSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user
     */
    omit?: userOmit<ExtArgs> | null
    /**
     * Filter, which user to fetch.
     */
    where: userWhereUniqueInput
  }

  /**
   * user findFirst
   */
  export type userFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user
     */
    select?: userSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user
     */
    omit?: userOmit<ExtArgs> | null
    /**
     * Filter, which user to fetch.
     */
    where?: userWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of users to fetch.
     */
    orderBy?: userOrderByWithRelationInput | userOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for users.
     */
    cursor?: userWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of users.
     */
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * user findFirstOrThrow
   */
  export type userFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user
     */
    select?: userSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user
     */
    omit?: userOmit<ExtArgs> | null
    /**
     * Filter, which user to fetch.
     */
    where?: userWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of users to fetch.
     */
    orderBy?: userOrderByWithRelationInput | userOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for users.
     */
    cursor?: userWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of users.
     */
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * user findMany
   */
  export type userFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user
     */
    select?: userSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user
     */
    omit?: userOmit<ExtArgs> | null
    /**
     * Filter, which users to fetch.
     */
    where?: userWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of users to fetch.
     */
    orderBy?: userOrderByWithRelationInput | userOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing users.
     */
    cursor?: userWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` users.
     */
    skip?: number
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * user create
   */
  export type userCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user
     */
    select?: userSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user
     */
    omit?: userOmit<ExtArgs> | null
    /**
     * The data needed to create a user.
     */
    data: XOR<userCreateInput, userUncheckedCreateInput>
  }

  /**
   * user createMany
   */
  export type userCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many users.
     */
    data: userCreateManyInput | userCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * user createManyAndReturn
   */
  export type userCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user
     */
    select?: userSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the user
     */
    omit?: userOmit<ExtArgs> | null
    /**
     * The data used to create many users.
     */
    data: userCreateManyInput | userCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * user update
   */
  export type userUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user
     */
    select?: userSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user
     */
    omit?: userOmit<ExtArgs> | null
    /**
     * The data needed to update a user.
     */
    data: XOR<userUpdateInput, userUncheckedUpdateInput>
    /**
     * Choose, which user to update.
     */
    where: userWhereUniqueInput
  }

  /**
   * user updateMany
   */
  export type userUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update users.
     */
    data: XOR<userUpdateManyMutationInput, userUncheckedUpdateManyInput>
    /**
     * Filter which users to update
     */
    where?: userWhereInput
    /**
     * Limit how many users to update.
     */
    limit?: number
  }

  /**
   * user updateManyAndReturn
   */
  export type userUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user
     */
    select?: userSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the user
     */
    omit?: userOmit<ExtArgs> | null
    /**
     * The data used to update users.
     */
    data: XOR<userUpdateManyMutationInput, userUncheckedUpdateManyInput>
    /**
     * Filter which users to update
     */
    where?: userWhereInput
    /**
     * Limit how many users to update.
     */
    limit?: number
  }

  /**
   * user upsert
   */
  export type userUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user
     */
    select?: userSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user
     */
    omit?: userOmit<ExtArgs> | null
    /**
     * The filter to search for the user to update in case it exists.
     */
    where: userWhereUniqueInput
    /**
     * In case the user found by the `where` argument doesn't exist, create a new user with this data.
     */
    create: XOR<userCreateInput, userUncheckedCreateInput>
    /**
     * In case the user was found with the provided `where` argument, update it with this data.
     */
    update: XOR<userUpdateInput, userUncheckedUpdateInput>
  }

  /**
   * user delete
   */
  export type userDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user
     */
    select?: userSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user
     */
    omit?: userOmit<ExtArgs> | null
    /**
     * Filter which user to delete.
     */
    where: userWhereUniqueInput
  }

  /**
   * user deleteMany
   */
  export type userDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which users to delete
     */
    where?: userWhereInput
    /**
     * Limit how many users to delete.
     */
    limit?: number
  }

  /**
   * user without action
   */
  export type userDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the user
     */
    select?: userSelect<ExtArgs> | null
    /**
     * Omit specific fields from the user
     */
    omit?: userOmit<ExtArgs> | null
  }


  /**
   * Model Setting
   */

  export type AggregateSetting = {
    _count: SettingCountAggregateOutputType | null
    _min: SettingMinAggregateOutputType | null
    _max: SettingMaxAggregateOutputType | null
  }

  export type SettingMinAggregateOutputType = {
    id: string | null
    site_name: string | null
    site_email: string | null
    site_phone: string | null
    site_logo: string | null
    site_address: string | null
    site_description: string | null
    site_footer: string | null
    client_side_url: string | null
    server_side_url: string | null
    otp_verification_type: string | null
    email_config_id: string | null
    cloud_config_id: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type SettingMaxAggregateOutputType = {
    id: string | null
    site_name: string | null
    site_email: string | null
    site_phone: string | null
    site_logo: string | null
    site_address: string | null
    site_description: string | null
    site_footer: string | null
    client_side_url: string | null
    server_side_url: string | null
    otp_verification_type: string | null
    email_config_id: string | null
    cloud_config_id: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type SettingCountAggregateOutputType = {
    id: number
    site_name: number
    site_email: number
    site_phone: number
    site_logo: number
    site_address: number
    site_description: number
    site_footer: number
    client_side_url: number
    server_side_url: number
    otp_verification_type: number
    email_config_id: number
    cloud_config_id: number
    stripe: number
    paypal: number
    razorpay: number
    mollie: number
    social_media_link: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type SettingMinAggregateInputType = {
    id?: true
    site_name?: true
    site_email?: true
    site_phone?: true
    site_logo?: true
    site_address?: true
    site_description?: true
    site_footer?: true
    client_side_url?: true
    server_side_url?: true
    otp_verification_type?: true
    email_config_id?: true
    cloud_config_id?: true
    createdAt?: true
    updatedAt?: true
  }

  export type SettingMaxAggregateInputType = {
    id?: true
    site_name?: true
    site_email?: true
    site_phone?: true
    site_logo?: true
    site_address?: true
    site_description?: true
    site_footer?: true
    client_side_url?: true
    server_side_url?: true
    otp_verification_type?: true
    email_config_id?: true
    cloud_config_id?: true
    createdAt?: true
    updatedAt?: true
  }

  export type SettingCountAggregateInputType = {
    id?: true
    site_name?: true
    site_email?: true
    site_phone?: true
    site_logo?: true
    site_address?: true
    site_description?: true
    site_footer?: true
    client_side_url?: true
    server_side_url?: true
    otp_verification_type?: true
    email_config_id?: true
    cloud_config_id?: true
    stripe?: true
    paypal?: true
    razorpay?: true
    mollie?: true
    social_media_link?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type SettingAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Setting to aggregate.
     */
    where?: SettingWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Settings to fetch.
     */
    orderBy?: SettingOrderByWithRelationInput | SettingOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: SettingWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Settings from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Settings.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Settings
    **/
    _count?: true | SettingCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: SettingMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: SettingMaxAggregateInputType
  }

  export type GetSettingAggregateType<T extends SettingAggregateArgs> = {
        [P in keyof T & keyof AggregateSetting]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateSetting[P]>
      : GetScalarType<T[P], AggregateSetting[P]>
  }




  export type SettingGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SettingWhereInput
    orderBy?: SettingOrderByWithAggregationInput | SettingOrderByWithAggregationInput[]
    by: SettingScalarFieldEnum[] | SettingScalarFieldEnum
    having?: SettingScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: SettingCountAggregateInputType | true
    _min?: SettingMinAggregateInputType
    _max?: SettingMaxAggregateInputType
  }

  export type SettingGroupByOutputType = {
    id: string
    site_name: string | null
    site_email: string | null
    site_phone: string | null
    site_logo: string | null
    site_address: string | null
    site_description: string | null
    site_footer: string | null
    client_side_url: string | null
    server_side_url: string | null
    otp_verification_type: string | null
    email_config_id: string | null
    cloud_config_id: string | null
    stripe: JsonValue | null
    paypal: JsonValue | null
    razorpay: JsonValue | null
    mollie: JsonValue | null
    social_media_link: JsonValue | null
    createdAt: Date
    updatedAt: Date
    _count: SettingCountAggregateOutputType | null
    _min: SettingMinAggregateOutputType | null
    _max: SettingMaxAggregateOutputType | null
  }

  type GetSettingGroupByPayload<T extends SettingGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<SettingGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof SettingGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], SettingGroupByOutputType[P]>
            : GetScalarType<T[P], SettingGroupByOutputType[P]>
        }
      >
    >


  export type SettingSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    site_name?: boolean
    site_email?: boolean
    site_phone?: boolean
    site_logo?: boolean
    site_address?: boolean
    site_description?: boolean
    site_footer?: boolean
    client_side_url?: boolean
    server_side_url?: boolean
    otp_verification_type?: boolean
    email_config_id?: boolean
    cloud_config_id?: boolean
    stripe?: boolean
    paypal?: boolean
    razorpay?: boolean
    mollie?: boolean
    social_media_link?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    email_config?: boolean | Setting$email_configArgs<ExtArgs>
    cloud_config?: boolean | Setting$cloud_configArgs<ExtArgs>
  }, ExtArgs["result"]["setting"]>

  export type SettingSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    site_name?: boolean
    site_email?: boolean
    site_phone?: boolean
    site_logo?: boolean
    site_address?: boolean
    site_description?: boolean
    site_footer?: boolean
    client_side_url?: boolean
    server_side_url?: boolean
    otp_verification_type?: boolean
    email_config_id?: boolean
    cloud_config_id?: boolean
    stripe?: boolean
    paypal?: boolean
    razorpay?: boolean
    mollie?: boolean
    social_media_link?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    email_config?: boolean | Setting$email_configArgs<ExtArgs>
    cloud_config?: boolean | Setting$cloud_configArgs<ExtArgs>
  }, ExtArgs["result"]["setting"]>

  export type SettingSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    site_name?: boolean
    site_email?: boolean
    site_phone?: boolean
    site_logo?: boolean
    site_address?: boolean
    site_description?: boolean
    site_footer?: boolean
    client_side_url?: boolean
    server_side_url?: boolean
    otp_verification_type?: boolean
    email_config_id?: boolean
    cloud_config_id?: boolean
    stripe?: boolean
    paypal?: boolean
    razorpay?: boolean
    mollie?: boolean
    social_media_link?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    email_config?: boolean | Setting$email_configArgs<ExtArgs>
    cloud_config?: boolean | Setting$cloud_configArgs<ExtArgs>
  }, ExtArgs["result"]["setting"]>

  export type SettingSelectScalar = {
    id?: boolean
    site_name?: boolean
    site_email?: boolean
    site_phone?: boolean
    site_logo?: boolean
    site_address?: boolean
    site_description?: boolean
    site_footer?: boolean
    client_side_url?: boolean
    server_side_url?: boolean
    otp_verification_type?: boolean
    email_config_id?: boolean
    cloud_config_id?: boolean
    stripe?: boolean
    paypal?: boolean
    razorpay?: boolean
    mollie?: boolean
    social_media_link?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type SettingOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "site_name" | "site_email" | "site_phone" | "site_logo" | "site_address" | "site_description" | "site_footer" | "client_side_url" | "server_side_url" | "otp_verification_type" | "email_config_id" | "cloud_config_id" | "stripe" | "paypal" | "razorpay" | "mollie" | "social_media_link" | "createdAt" | "updatedAt", ExtArgs["result"]["setting"]>
  export type SettingInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    email_config?: boolean | Setting$email_configArgs<ExtArgs>
    cloud_config?: boolean | Setting$cloud_configArgs<ExtArgs>
  }
  export type SettingIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    email_config?: boolean | Setting$email_configArgs<ExtArgs>
    cloud_config?: boolean | Setting$cloud_configArgs<ExtArgs>
  }
  export type SettingIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    email_config?: boolean | Setting$email_configArgs<ExtArgs>
    cloud_config?: boolean | Setting$cloud_configArgs<ExtArgs>
  }

  export type $SettingPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Setting"
    objects: {
      email_config: Prisma.$EmailConfigPayload<ExtArgs> | null
      cloud_config: Prisma.$CloudConfigPayload<ExtArgs> | null
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      site_name: string | null
      site_email: string | null
      site_phone: string | null
      site_logo: string | null
      site_address: string | null
      site_description: string | null
      site_footer: string | null
      client_side_url: string | null
      server_side_url: string | null
      otp_verification_type: string | null
      email_config_id: string | null
      cloud_config_id: string | null
      stripe: Prisma.JsonValue | null
      paypal: Prisma.JsonValue | null
      razorpay: Prisma.JsonValue | null
      mollie: Prisma.JsonValue | null
      social_media_link: Prisma.JsonValue | null
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["setting"]>
    composites: {}
  }

  type SettingGetPayload<S extends boolean | null | undefined | SettingDefaultArgs> = $Result.GetResult<Prisma.$SettingPayload, S>

  type SettingCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<SettingFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: SettingCountAggregateInputType | true
    }

  export interface SettingDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Setting'], meta: { name: 'Setting' } }
    /**
     * Find zero or one Setting that matches the filter.
     * @param {SettingFindUniqueArgs} args - Arguments to find a Setting
     * @example
     * // Get one Setting
     * const setting = await prisma.setting.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends SettingFindUniqueArgs>(args: SelectSubset<T, SettingFindUniqueArgs<ExtArgs>>): Prisma__SettingClient<$Result.GetResult<Prisma.$SettingPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Setting that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {SettingFindUniqueOrThrowArgs} args - Arguments to find a Setting
     * @example
     * // Get one Setting
     * const setting = await prisma.setting.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends SettingFindUniqueOrThrowArgs>(args: SelectSubset<T, SettingFindUniqueOrThrowArgs<ExtArgs>>): Prisma__SettingClient<$Result.GetResult<Prisma.$SettingPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Setting that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SettingFindFirstArgs} args - Arguments to find a Setting
     * @example
     * // Get one Setting
     * const setting = await prisma.setting.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends SettingFindFirstArgs>(args?: SelectSubset<T, SettingFindFirstArgs<ExtArgs>>): Prisma__SettingClient<$Result.GetResult<Prisma.$SettingPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Setting that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SettingFindFirstOrThrowArgs} args - Arguments to find a Setting
     * @example
     * // Get one Setting
     * const setting = await prisma.setting.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends SettingFindFirstOrThrowArgs>(args?: SelectSubset<T, SettingFindFirstOrThrowArgs<ExtArgs>>): Prisma__SettingClient<$Result.GetResult<Prisma.$SettingPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Settings that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SettingFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Settings
     * const settings = await prisma.setting.findMany()
     * 
     * // Get first 10 Settings
     * const settings = await prisma.setting.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const settingWithIdOnly = await prisma.setting.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends SettingFindManyArgs>(args?: SelectSubset<T, SettingFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SettingPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Setting.
     * @param {SettingCreateArgs} args - Arguments to create a Setting.
     * @example
     * // Create one Setting
     * const Setting = await prisma.setting.create({
     *   data: {
     *     // ... data to create a Setting
     *   }
     * })
     * 
     */
    create<T extends SettingCreateArgs>(args: SelectSubset<T, SettingCreateArgs<ExtArgs>>): Prisma__SettingClient<$Result.GetResult<Prisma.$SettingPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Settings.
     * @param {SettingCreateManyArgs} args - Arguments to create many Settings.
     * @example
     * // Create many Settings
     * const setting = await prisma.setting.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends SettingCreateManyArgs>(args?: SelectSubset<T, SettingCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Settings and returns the data saved in the database.
     * @param {SettingCreateManyAndReturnArgs} args - Arguments to create many Settings.
     * @example
     * // Create many Settings
     * const setting = await prisma.setting.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Settings and only return the `id`
     * const settingWithIdOnly = await prisma.setting.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends SettingCreateManyAndReturnArgs>(args?: SelectSubset<T, SettingCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SettingPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Setting.
     * @param {SettingDeleteArgs} args - Arguments to delete one Setting.
     * @example
     * // Delete one Setting
     * const Setting = await prisma.setting.delete({
     *   where: {
     *     // ... filter to delete one Setting
     *   }
     * })
     * 
     */
    delete<T extends SettingDeleteArgs>(args: SelectSubset<T, SettingDeleteArgs<ExtArgs>>): Prisma__SettingClient<$Result.GetResult<Prisma.$SettingPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Setting.
     * @param {SettingUpdateArgs} args - Arguments to update one Setting.
     * @example
     * // Update one Setting
     * const setting = await prisma.setting.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends SettingUpdateArgs>(args: SelectSubset<T, SettingUpdateArgs<ExtArgs>>): Prisma__SettingClient<$Result.GetResult<Prisma.$SettingPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Settings.
     * @param {SettingDeleteManyArgs} args - Arguments to filter Settings to delete.
     * @example
     * // Delete a few Settings
     * const { count } = await prisma.setting.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends SettingDeleteManyArgs>(args?: SelectSubset<T, SettingDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Settings.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SettingUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Settings
     * const setting = await prisma.setting.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends SettingUpdateManyArgs>(args: SelectSubset<T, SettingUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Settings and returns the data updated in the database.
     * @param {SettingUpdateManyAndReturnArgs} args - Arguments to update many Settings.
     * @example
     * // Update many Settings
     * const setting = await prisma.setting.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Settings and only return the `id`
     * const settingWithIdOnly = await prisma.setting.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends SettingUpdateManyAndReturnArgs>(args: SelectSubset<T, SettingUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SettingPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Setting.
     * @param {SettingUpsertArgs} args - Arguments to update or create a Setting.
     * @example
     * // Update or create a Setting
     * const setting = await prisma.setting.upsert({
     *   create: {
     *     // ... data to create a Setting
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Setting we want to update
     *   }
     * })
     */
    upsert<T extends SettingUpsertArgs>(args: SelectSubset<T, SettingUpsertArgs<ExtArgs>>): Prisma__SettingClient<$Result.GetResult<Prisma.$SettingPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Settings.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SettingCountArgs} args - Arguments to filter Settings to count.
     * @example
     * // Count the number of Settings
     * const count = await prisma.setting.count({
     *   where: {
     *     // ... the filter for the Settings we want to count
     *   }
     * })
    **/
    count<T extends SettingCountArgs>(
      args?: Subset<T, SettingCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], SettingCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Setting.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SettingAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends SettingAggregateArgs>(args: Subset<T, SettingAggregateArgs>): Prisma.PrismaPromise<GetSettingAggregateType<T>>

    /**
     * Group by Setting.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SettingGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends SettingGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: SettingGroupByArgs['orderBy'] }
        : { orderBy?: SettingGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, SettingGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetSettingGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Setting model
   */
  readonly fields: SettingFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Setting.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__SettingClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    email_config<T extends Setting$email_configArgs<ExtArgs> = {}>(args?: Subset<T, Setting$email_configArgs<ExtArgs>>): Prisma__EmailConfigClient<$Result.GetResult<Prisma.$EmailConfigPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    cloud_config<T extends Setting$cloud_configArgs<ExtArgs> = {}>(args?: Subset<T, Setting$cloud_configArgs<ExtArgs>>): Prisma__CloudConfigClient<$Result.GetResult<Prisma.$CloudConfigPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Setting model
   */
  interface SettingFieldRefs {
    readonly id: FieldRef<"Setting", 'String'>
    readonly site_name: FieldRef<"Setting", 'String'>
    readonly site_email: FieldRef<"Setting", 'String'>
    readonly site_phone: FieldRef<"Setting", 'String'>
    readonly site_logo: FieldRef<"Setting", 'String'>
    readonly site_address: FieldRef<"Setting", 'String'>
    readonly site_description: FieldRef<"Setting", 'String'>
    readonly site_footer: FieldRef<"Setting", 'String'>
    readonly client_side_url: FieldRef<"Setting", 'String'>
    readonly server_side_url: FieldRef<"Setting", 'String'>
    readonly otp_verification_type: FieldRef<"Setting", 'String'>
    readonly email_config_id: FieldRef<"Setting", 'String'>
    readonly cloud_config_id: FieldRef<"Setting", 'String'>
    readonly stripe: FieldRef<"Setting", 'Json'>
    readonly paypal: FieldRef<"Setting", 'Json'>
    readonly razorpay: FieldRef<"Setting", 'Json'>
    readonly mollie: FieldRef<"Setting", 'Json'>
    readonly social_media_link: FieldRef<"Setting", 'Json'>
    readonly createdAt: FieldRef<"Setting", 'DateTime'>
    readonly updatedAt: FieldRef<"Setting", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Setting findUnique
   */
  export type SettingFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Setting
     */
    select?: SettingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Setting
     */
    omit?: SettingOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SettingInclude<ExtArgs> | null
    /**
     * Filter, which Setting to fetch.
     */
    where: SettingWhereUniqueInput
  }

  /**
   * Setting findUniqueOrThrow
   */
  export type SettingFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Setting
     */
    select?: SettingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Setting
     */
    omit?: SettingOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SettingInclude<ExtArgs> | null
    /**
     * Filter, which Setting to fetch.
     */
    where: SettingWhereUniqueInput
  }

  /**
   * Setting findFirst
   */
  export type SettingFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Setting
     */
    select?: SettingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Setting
     */
    omit?: SettingOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SettingInclude<ExtArgs> | null
    /**
     * Filter, which Setting to fetch.
     */
    where?: SettingWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Settings to fetch.
     */
    orderBy?: SettingOrderByWithRelationInput | SettingOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Settings.
     */
    cursor?: SettingWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Settings from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Settings.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Settings.
     */
    distinct?: SettingScalarFieldEnum | SettingScalarFieldEnum[]
  }

  /**
   * Setting findFirstOrThrow
   */
  export type SettingFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Setting
     */
    select?: SettingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Setting
     */
    omit?: SettingOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SettingInclude<ExtArgs> | null
    /**
     * Filter, which Setting to fetch.
     */
    where?: SettingWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Settings to fetch.
     */
    orderBy?: SettingOrderByWithRelationInput | SettingOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Settings.
     */
    cursor?: SettingWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Settings from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Settings.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Settings.
     */
    distinct?: SettingScalarFieldEnum | SettingScalarFieldEnum[]
  }

  /**
   * Setting findMany
   */
  export type SettingFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Setting
     */
    select?: SettingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Setting
     */
    omit?: SettingOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SettingInclude<ExtArgs> | null
    /**
     * Filter, which Settings to fetch.
     */
    where?: SettingWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Settings to fetch.
     */
    orderBy?: SettingOrderByWithRelationInput | SettingOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Settings.
     */
    cursor?: SettingWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Settings from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Settings.
     */
    skip?: number
    distinct?: SettingScalarFieldEnum | SettingScalarFieldEnum[]
  }

  /**
   * Setting create
   */
  export type SettingCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Setting
     */
    select?: SettingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Setting
     */
    omit?: SettingOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SettingInclude<ExtArgs> | null
    /**
     * The data needed to create a Setting.
     */
    data: XOR<SettingCreateInput, SettingUncheckedCreateInput>
  }

  /**
   * Setting createMany
   */
  export type SettingCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Settings.
     */
    data: SettingCreateManyInput | SettingCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Setting createManyAndReturn
   */
  export type SettingCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Setting
     */
    select?: SettingSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Setting
     */
    omit?: SettingOmit<ExtArgs> | null
    /**
     * The data used to create many Settings.
     */
    data: SettingCreateManyInput | SettingCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SettingIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * Setting update
   */
  export type SettingUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Setting
     */
    select?: SettingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Setting
     */
    omit?: SettingOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SettingInclude<ExtArgs> | null
    /**
     * The data needed to update a Setting.
     */
    data: XOR<SettingUpdateInput, SettingUncheckedUpdateInput>
    /**
     * Choose, which Setting to update.
     */
    where: SettingWhereUniqueInput
  }

  /**
   * Setting updateMany
   */
  export type SettingUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Settings.
     */
    data: XOR<SettingUpdateManyMutationInput, SettingUncheckedUpdateManyInput>
    /**
     * Filter which Settings to update
     */
    where?: SettingWhereInput
    /**
     * Limit how many Settings to update.
     */
    limit?: number
  }

  /**
   * Setting updateManyAndReturn
   */
  export type SettingUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Setting
     */
    select?: SettingSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Setting
     */
    omit?: SettingOmit<ExtArgs> | null
    /**
     * The data used to update Settings.
     */
    data: XOR<SettingUpdateManyMutationInput, SettingUncheckedUpdateManyInput>
    /**
     * Filter which Settings to update
     */
    where?: SettingWhereInput
    /**
     * Limit how many Settings to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SettingIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * Setting upsert
   */
  export type SettingUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Setting
     */
    select?: SettingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Setting
     */
    omit?: SettingOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SettingInclude<ExtArgs> | null
    /**
     * The filter to search for the Setting to update in case it exists.
     */
    where: SettingWhereUniqueInput
    /**
     * In case the Setting found by the `where` argument doesn't exist, create a new Setting with this data.
     */
    create: XOR<SettingCreateInput, SettingUncheckedCreateInput>
    /**
     * In case the Setting was found with the provided `where` argument, update it with this data.
     */
    update: XOR<SettingUpdateInput, SettingUncheckedUpdateInput>
  }

  /**
   * Setting delete
   */
  export type SettingDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Setting
     */
    select?: SettingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Setting
     */
    omit?: SettingOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SettingInclude<ExtArgs> | null
    /**
     * Filter which Setting to delete.
     */
    where: SettingWhereUniqueInput
  }

  /**
   * Setting deleteMany
   */
  export type SettingDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Settings to delete
     */
    where?: SettingWhereInput
    /**
     * Limit how many Settings to delete.
     */
    limit?: number
  }

  /**
   * Setting.email_config
   */
  export type Setting$email_configArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the EmailConfig
     */
    select?: EmailConfigSelect<ExtArgs> | null
    /**
     * Omit specific fields from the EmailConfig
     */
    omit?: EmailConfigOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EmailConfigInclude<ExtArgs> | null
    where?: EmailConfigWhereInput
  }

  /**
   * Setting.cloud_config
   */
  export type Setting$cloud_configArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CloudConfig
     */
    select?: CloudConfigSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CloudConfig
     */
    omit?: CloudConfigOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CloudConfigInclude<ExtArgs> | null
    where?: CloudConfigWhereInput
  }

  /**
   * Setting without action
   */
  export type SettingDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Setting
     */
    select?: SettingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Setting
     */
    omit?: SettingOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SettingInclude<ExtArgs> | null
  }


  /**
   * Model EmailConfig
   */

  export type AggregateEmailConfig = {
    _count: EmailConfigCountAggregateOutputType | null
    _min: EmailConfigMinAggregateOutputType | null
    _max: EmailConfigMaxAggregateOutputType | null
  }

  export type EmailConfigMinAggregateOutputType = {
    id: string | null
    resend_api_key: string | null
    resend_email: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type EmailConfigMaxAggregateOutputType = {
    id: string | null
    resend_api_key: string | null
    resend_email: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type EmailConfigCountAggregateOutputType = {
    id: number
    resend_api_key: number
    resend_email: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type EmailConfigMinAggregateInputType = {
    id?: true
    resend_api_key?: true
    resend_email?: true
    createdAt?: true
    updatedAt?: true
  }

  export type EmailConfigMaxAggregateInputType = {
    id?: true
    resend_api_key?: true
    resend_email?: true
    createdAt?: true
    updatedAt?: true
  }

  export type EmailConfigCountAggregateInputType = {
    id?: true
    resend_api_key?: true
    resend_email?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type EmailConfigAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which EmailConfig to aggregate.
     */
    where?: EmailConfigWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of EmailConfigs to fetch.
     */
    orderBy?: EmailConfigOrderByWithRelationInput | EmailConfigOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: EmailConfigWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` EmailConfigs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` EmailConfigs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned EmailConfigs
    **/
    _count?: true | EmailConfigCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: EmailConfigMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: EmailConfigMaxAggregateInputType
  }

  export type GetEmailConfigAggregateType<T extends EmailConfigAggregateArgs> = {
        [P in keyof T & keyof AggregateEmailConfig]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateEmailConfig[P]>
      : GetScalarType<T[P], AggregateEmailConfig[P]>
  }




  export type EmailConfigGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: EmailConfigWhereInput
    orderBy?: EmailConfigOrderByWithAggregationInput | EmailConfigOrderByWithAggregationInput[]
    by: EmailConfigScalarFieldEnum[] | EmailConfigScalarFieldEnum
    having?: EmailConfigScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: EmailConfigCountAggregateInputType | true
    _min?: EmailConfigMinAggregateInputType
    _max?: EmailConfigMaxAggregateInputType
  }

  export type EmailConfigGroupByOutputType = {
    id: string
    resend_api_key: string
    resend_email: string
    createdAt: Date
    updatedAt: Date
    _count: EmailConfigCountAggregateOutputType | null
    _min: EmailConfigMinAggregateOutputType | null
    _max: EmailConfigMaxAggregateOutputType | null
  }

  type GetEmailConfigGroupByPayload<T extends EmailConfigGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<EmailConfigGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof EmailConfigGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], EmailConfigGroupByOutputType[P]>
            : GetScalarType<T[P], EmailConfigGroupByOutputType[P]>
        }
      >
    >


  export type EmailConfigSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    resend_api_key?: boolean
    resend_email?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    setting?: boolean | EmailConfig$settingArgs<ExtArgs>
  }, ExtArgs["result"]["emailConfig"]>

  export type EmailConfigSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    resend_api_key?: boolean
    resend_email?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["emailConfig"]>

  export type EmailConfigSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    resend_api_key?: boolean
    resend_email?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["emailConfig"]>

  export type EmailConfigSelectScalar = {
    id?: boolean
    resend_api_key?: boolean
    resend_email?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type EmailConfigOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "resend_api_key" | "resend_email" | "createdAt" | "updatedAt", ExtArgs["result"]["emailConfig"]>
  export type EmailConfigInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    setting?: boolean | EmailConfig$settingArgs<ExtArgs>
  }
  export type EmailConfigIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}
  export type EmailConfigIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}

  export type $EmailConfigPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "EmailConfig"
    objects: {
      setting: Prisma.$SettingPayload<ExtArgs> | null
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      resend_api_key: string
      resend_email: string
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["emailConfig"]>
    composites: {}
  }

  type EmailConfigGetPayload<S extends boolean | null | undefined | EmailConfigDefaultArgs> = $Result.GetResult<Prisma.$EmailConfigPayload, S>

  type EmailConfigCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<EmailConfigFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: EmailConfigCountAggregateInputType | true
    }

  export interface EmailConfigDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['EmailConfig'], meta: { name: 'EmailConfig' } }
    /**
     * Find zero or one EmailConfig that matches the filter.
     * @param {EmailConfigFindUniqueArgs} args - Arguments to find a EmailConfig
     * @example
     * // Get one EmailConfig
     * const emailConfig = await prisma.emailConfig.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends EmailConfigFindUniqueArgs>(args: SelectSubset<T, EmailConfigFindUniqueArgs<ExtArgs>>): Prisma__EmailConfigClient<$Result.GetResult<Prisma.$EmailConfigPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one EmailConfig that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {EmailConfigFindUniqueOrThrowArgs} args - Arguments to find a EmailConfig
     * @example
     * // Get one EmailConfig
     * const emailConfig = await prisma.emailConfig.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends EmailConfigFindUniqueOrThrowArgs>(args: SelectSubset<T, EmailConfigFindUniqueOrThrowArgs<ExtArgs>>): Prisma__EmailConfigClient<$Result.GetResult<Prisma.$EmailConfigPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first EmailConfig that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EmailConfigFindFirstArgs} args - Arguments to find a EmailConfig
     * @example
     * // Get one EmailConfig
     * const emailConfig = await prisma.emailConfig.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends EmailConfigFindFirstArgs>(args?: SelectSubset<T, EmailConfigFindFirstArgs<ExtArgs>>): Prisma__EmailConfigClient<$Result.GetResult<Prisma.$EmailConfigPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first EmailConfig that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EmailConfigFindFirstOrThrowArgs} args - Arguments to find a EmailConfig
     * @example
     * // Get one EmailConfig
     * const emailConfig = await prisma.emailConfig.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends EmailConfigFindFirstOrThrowArgs>(args?: SelectSubset<T, EmailConfigFindFirstOrThrowArgs<ExtArgs>>): Prisma__EmailConfigClient<$Result.GetResult<Prisma.$EmailConfigPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more EmailConfigs that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EmailConfigFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all EmailConfigs
     * const emailConfigs = await prisma.emailConfig.findMany()
     * 
     * // Get first 10 EmailConfigs
     * const emailConfigs = await prisma.emailConfig.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const emailConfigWithIdOnly = await prisma.emailConfig.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends EmailConfigFindManyArgs>(args?: SelectSubset<T, EmailConfigFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$EmailConfigPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a EmailConfig.
     * @param {EmailConfigCreateArgs} args - Arguments to create a EmailConfig.
     * @example
     * // Create one EmailConfig
     * const EmailConfig = await prisma.emailConfig.create({
     *   data: {
     *     // ... data to create a EmailConfig
     *   }
     * })
     * 
     */
    create<T extends EmailConfigCreateArgs>(args: SelectSubset<T, EmailConfigCreateArgs<ExtArgs>>): Prisma__EmailConfigClient<$Result.GetResult<Prisma.$EmailConfigPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many EmailConfigs.
     * @param {EmailConfigCreateManyArgs} args - Arguments to create many EmailConfigs.
     * @example
     * // Create many EmailConfigs
     * const emailConfig = await prisma.emailConfig.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends EmailConfigCreateManyArgs>(args?: SelectSubset<T, EmailConfigCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many EmailConfigs and returns the data saved in the database.
     * @param {EmailConfigCreateManyAndReturnArgs} args - Arguments to create many EmailConfigs.
     * @example
     * // Create many EmailConfigs
     * const emailConfig = await prisma.emailConfig.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many EmailConfigs and only return the `id`
     * const emailConfigWithIdOnly = await prisma.emailConfig.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends EmailConfigCreateManyAndReturnArgs>(args?: SelectSubset<T, EmailConfigCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$EmailConfigPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a EmailConfig.
     * @param {EmailConfigDeleteArgs} args - Arguments to delete one EmailConfig.
     * @example
     * // Delete one EmailConfig
     * const EmailConfig = await prisma.emailConfig.delete({
     *   where: {
     *     // ... filter to delete one EmailConfig
     *   }
     * })
     * 
     */
    delete<T extends EmailConfigDeleteArgs>(args: SelectSubset<T, EmailConfigDeleteArgs<ExtArgs>>): Prisma__EmailConfigClient<$Result.GetResult<Prisma.$EmailConfigPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one EmailConfig.
     * @param {EmailConfigUpdateArgs} args - Arguments to update one EmailConfig.
     * @example
     * // Update one EmailConfig
     * const emailConfig = await prisma.emailConfig.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends EmailConfigUpdateArgs>(args: SelectSubset<T, EmailConfigUpdateArgs<ExtArgs>>): Prisma__EmailConfigClient<$Result.GetResult<Prisma.$EmailConfigPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more EmailConfigs.
     * @param {EmailConfigDeleteManyArgs} args - Arguments to filter EmailConfigs to delete.
     * @example
     * // Delete a few EmailConfigs
     * const { count } = await prisma.emailConfig.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends EmailConfigDeleteManyArgs>(args?: SelectSubset<T, EmailConfigDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more EmailConfigs.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EmailConfigUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many EmailConfigs
     * const emailConfig = await prisma.emailConfig.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends EmailConfigUpdateManyArgs>(args: SelectSubset<T, EmailConfigUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more EmailConfigs and returns the data updated in the database.
     * @param {EmailConfigUpdateManyAndReturnArgs} args - Arguments to update many EmailConfigs.
     * @example
     * // Update many EmailConfigs
     * const emailConfig = await prisma.emailConfig.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more EmailConfigs and only return the `id`
     * const emailConfigWithIdOnly = await prisma.emailConfig.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends EmailConfigUpdateManyAndReturnArgs>(args: SelectSubset<T, EmailConfigUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$EmailConfigPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one EmailConfig.
     * @param {EmailConfigUpsertArgs} args - Arguments to update or create a EmailConfig.
     * @example
     * // Update or create a EmailConfig
     * const emailConfig = await prisma.emailConfig.upsert({
     *   create: {
     *     // ... data to create a EmailConfig
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the EmailConfig we want to update
     *   }
     * })
     */
    upsert<T extends EmailConfigUpsertArgs>(args: SelectSubset<T, EmailConfigUpsertArgs<ExtArgs>>): Prisma__EmailConfigClient<$Result.GetResult<Prisma.$EmailConfigPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of EmailConfigs.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EmailConfigCountArgs} args - Arguments to filter EmailConfigs to count.
     * @example
     * // Count the number of EmailConfigs
     * const count = await prisma.emailConfig.count({
     *   where: {
     *     // ... the filter for the EmailConfigs we want to count
     *   }
     * })
    **/
    count<T extends EmailConfigCountArgs>(
      args?: Subset<T, EmailConfigCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], EmailConfigCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a EmailConfig.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EmailConfigAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends EmailConfigAggregateArgs>(args: Subset<T, EmailConfigAggregateArgs>): Prisma.PrismaPromise<GetEmailConfigAggregateType<T>>

    /**
     * Group by EmailConfig.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {EmailConfigGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends EmailConfigGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: EmailConfigGroupByArgs['orderBy'] }
        : { orderBy?: EmailConfigGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, EmailConfigGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetEmailConfigGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the EmailConfig model
   */
  readonly fields: EmailConfigFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for EmailConfig.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__EmailConfigClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    setting<T extends EmailConfig$settingArgs<ExtArgs> = {}>(args?: Subset<T, EmailConfig$settingArgs<ExtArgs>>): Prisma__SettingClient<$Result.GetResult<Prisma.$SettingPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the EmailConfig model
   */
  interface EmailConfigFieldRefs {
    readonly id: FieldRef<"EmailConfig", 'String'>
    readonly resend_api_key: FieldRef<"EmailConfig", 'String'>
    readonly resend_email: FieldRef<"EmailConfig", 'String'>
    readonly createdAt: FieldRef<"EmailConfig", 'DateTime'>
    readonly updatedAt: FieldRef<"EmailConfig", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * EmailConfig findUnique
   */
  export type EmailConfigFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the EmailConfig
     */
    select?: EmailConfigSelect<ExtArgs> | null
    /**
     * Omit specific fields from the EmailConfig
     */
    omit?: EmailConfigOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EmailConfigInclude<ExtArgs> | null
    /**
     * Filter, which EmailConfig to fetch.
     */
    where: EmailConfigWhereUniqueInput
  }

  /**
   * EmailConfig findUniqueOrThrow
   */
  export type EmailConfigFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the EmailConfig
     */
    select?: EmailConfigSelect<ExtArgs> | null
    /**
     * Omit specific fields from the EmailConfig
     */
    omit?: EmailConfigOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EmailConfigInclude<ExtArgs> | null
    /**
     * Filter, which EmailConfig to fetch.
     */
    where: EmailConfigWhereUniqueInput
  }

  /**
   * EmailConfig findFirst
   */
  export type EmailConfigFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the EmailConfig
     */
    select?: EmailConfigSelect<ExtArgs> | null
    /**
     * Omit specific fields from the EmailConfig
     */
    omit?: EmailConfigOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EmailConfigInclude<ExtArgs> | null
    /**
     * Filter, which EmailConfig to fetch.
     */
    where?: EmailConfigWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of EmailConfigs to fetch.
     */
    orderBy?: EmailConfigOrderByWithRelationInput | EmailConfigOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for EmailConfigs.
     */
    cursor?: EmailConfigWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` EmailConfigs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` EmailConfigs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of EmailConfigs.
     */
    distinct?: EmailConfigScalarFieldEnum | EmailConfigScalarFieldEnum[]
  }

  /**
   * EmailConfig findFirstOrThrow
   */
  export type EmailConfigFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the EmailConfig
     */
    select?: EmailConfigSelect<ExtArgs> | null
    /**
     * Omit specific fields from the EmailConfig
     */
    omit?: EmailConfigOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EmailConfigInclude<ExtArgs> | null
    /**
     * Filter, which EmailConfig to fetch.
     */
    where?: EmailConfigWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of EmailConfigs to fetch.
     */
    orderBy?: EmailConfigOrderByWithRelationInput | EmailConfigOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for EmailConfigs.
     */
    cursor?: EmailConfigWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` EmailConfigs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` EmailConfigs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of EmailConfigs.
     */
    distinct?: EmailConfigScalarFieldEnum | EmailConfigScalarFieldEnum[]
  }

  /**
   * EmailConfig findMany
   */
  export type EmailConfigFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the EmailConfig
     */
    select?: EmailConfigSelect<ExtArgs> | null
    /**
     * Omit specific fields from the EmailConfig
     */
    omit?: EmailConfigOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EmailConfigInclude<ExtArgs> | null
    /**
     * Filter, which EmailConfigs to fetch.
     */
    where?: EmailConfigWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of EmailConfigs to fetch.
     */
    orderBy?: EmailConfigOrderByWithRelationInput | EmailConfigOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing EmailConfigs.
     */
    cursor?: EmailConfigWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` EmailConfigs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` EmailConfigs.
     */
    skip?: number
    distinct?: EmailConfigScalarFieldEnum | EmailConfigScalarFieldEnum[]
  }

  /**
   * EmailConfig create
   */
  export type EmailConfigCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the EmailConfig
     */
    select?: EmailConfigSelect<ExtArgs> | null
    /**
     * Omit specific fields from the EmailConfig
     */
    omit?: EmailConfigOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EmailConfigInclude<ExtArgs> | null
    /**
     * The data needed to create a EmailConfig.
     */
    data: XOR<EmailConfigCreateInput, EmailConfigUncheckedCreateInput>
  }

  /**
   * EmailConfig createMany
   */
  export type EmailConfigCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many EmailConfigs.
     */
    data: EmailConfigCreateManyInput | EmailConfigCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * EmailConfig createManyAndReturn
   */
  export type EmailConfigCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the EmailConfig
     */
    select?: EmailConfigSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the EmailConfig
     */
    omit?: EmailConfigOmit<ExtArgs> | null
    /**
     * The data used to create many EmailConfigs.
     */
    data: EmailConfigCreateManyInput | EmailConfigCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * EmailConfig update
   */
  export type EmailConfigUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the EmailConfig
     */
    select?: EmailConfigSelect<ExtArgs> | null
    /**
     * Omit specific fields from the EmailConfig
     */
    omit?: EmailConfigOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EmailConfigInclude<ExtArgs> | null
    /**
     * The data needed to update a EmailConfig.
     */
    data: XOR<EmailConfigUpdateInput, EmailConfigUncheckedUpdateInput>
    /**
     * Choose, which EmailConfig to update.
     */
    where: EmailConfigWhereUniqueInput
  }

  /**
   * EmailConfig updateMany
   */
  export type EmailConfigUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update EmailConfigs.
     */
    data: XOR<EmailConfigUpdateManyMutationInput, EmailConfigUncheckedUpdateManyInput>
    /**
     * Filter which EmailConfigs to update
     */
    where?: EmailConfigWhereInput
    /**
     * Limit how many EmailConfigs to update.
     */
    limit?: number
  }

  /**
   * EmailConfig updateManyAndReturn
   */
  export type EmailConfigUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the EmailConfig
     */
    select?: EmailConfigSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the EmailConfig
     */
    omit?: EmailConfigOmit<ExtArgs> | null
    /**
     * The data used to update EmailConfigs.
     */
    data: XOR<EmailConfigUpdateManyMutationInput, EmailConfigUncheckedUpdateManyInput>
    /**
     * Filter which EmailConfigs to update
     */
    where?: EmailConfigWhereInput
    /**
     * Limit how many EmailConfigs to update.
     */
    limit?: number
  }

  /**
   * EmailConfig upsert
   */
  export type EmailConfigUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the EmailConfig
     */
    select?: EmailConfigSelect<ExtArgs> | null
    /**
     * Omit specific fields from the EmailConfig
     */
    omit?: EmailConfigOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EmailConfigInclude<ExtArgs> | null
    /**
     * The filter to search for the EmailConfig to update in case it exists.
     */
    where: EmailConfigWhereUniqueInput
    /**
     * In case the EmailConfig found by the `where` argument doesn't exist, create a new EmailConfig with this data.
     */
    create: XOR<EmailConfigCreateInput, EmailConfigUncheckedCreateInput>
    /**
     * In case the EmailConfig was found with the provided `where` argument, update it with this data.
     */
    update: XOR<EmailConfigUpdateInput, EmailConfigUncheckedUpdateInput>
  }

  /**
   * EmailConfig delete
   */
  export type EmailConfigDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the EmailConfig
     */
    select?: EmailConfigSelect<ExtArgs> | null
    /**
     * Omit specific fields from the EmailConfig
     */
    omit?: EmailConfigOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EmailConfigInclude<ExtArgs> | null
    /**
     * Filter which EmailConfig to delete.
     */
    where: EmailConfigWhereUniqueInput
  }

  /**
   * EmailConfig deleteMany
   */
  export type EmailConfigDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which EmailConfigs to delete
     */
    where?: EmailConfigWhereInput
    /**
     * Limit how many EmailConfigs to delete.
     */
    limit?: number
  }

  /**
   * EmailConfig.setting
   */
  export type EmailConfig$settingArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Setting
     */
    select?: SettingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Setting
     */
    omit?: SettingOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SettingInclude<ExtArgs> | null
    where?: SettingWhereInput
  }

  /**
   * EmailConfig without action
   */
  export type EmailConfigDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the EmailConfig
     */
    select?: EmailConfigSelect<ExtArgs> | null
    /**
     * Omit specific fields from the EmailConfig
     */
    omit?: EmailConfigOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: EmailConfigInclude<ExtArgs> | null
  }


  /**
   * Model CloudConfig
   */

  export type AggregateCloudConfig = {
    _count: CloudConfigCountAggregateOutputType | null
    _min: CloudConfigMinAggregateOutputType | null
    _max: CloudConfigMaxAggregateOutputType | null
  }

  export type CloudConfigMinAggregateOutputType = {
    id: string | null
    cloud_name: string | null
    api_key: string | null
    api_secret: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type CloudConfigMaxAggregateOutputType = {
    id: string | null
    cloud_name: string | null
    api_key: string | null
    api_secret: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type CloudConfigCountAggregateOutputType = {
    id: number
    cloud_name: number
    api_key: number
    api_secret: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type CloudConfigMinAggregateInputType = {
    id?: true
    cloud_name?: true
    api_key?: true
    api_secret?: true
    createdAt?: true
    updatedAt?: true
  }

  export type CloudConfigMaxAggregateInputType = {
    id?: true
    cloud_name?: true
    api_key?: true
    api_secret?: true
    createdAt?: true
    updatedAt?: true
  }

  export type CloudConfigCountAggregateInputType = {
    id?: true
    cloud_name?: true
    api_key?: true
    api_secret?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type CloudConfigAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which CloudConfig to aggregate.
     */
    where?: CloudConfigWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of CloudConfigs to fetch.
     */
    orderBy?: CloudConfigOrderByWithRelationInput | CloudConfigOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: CloudConfigWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` CloudConfigs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` CloudConfigs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned CloudConfigs
    **/
    _count?: true | CloudConfigCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: CloudConfigMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: CloudConfigMaxAggregateInputType
  }

  export type GetCloudConfigAggregateType<T extends CloudConfigAggregateArgs> = {
        [P in keyof T & keyof AggregateCloudConfig]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateCloudConfig[P]>
      : GetScalarType<T[P], AggregateCloudConfig[P]>
  }




  export type CloudConfigGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: CloudConfigWhereInput
    orderBy?: CloudConfigOrderByWithAggregationInput | CloudConfigOrderByWithAggregationInput[]
    by: CloudConfigScalarFieldEnum[] | CloudConfigScalarFieldEnum
    having?: CloudConfigScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: CloudConfigCountAggregateInputType | true
    _min?: CloudConfigMinAggregateInputType
    _max?: CloudConfigMaxAggregateInputType
  }

  export type CloudConfigGroupByOutputType = {
    id: string
    cloud_name: string
    api_key: string
    api_secret: string
    createdAt: Date
    updatedAt: Date
    _count: CloudConfigCountAggregateOutputType | null
    _min: CloudConfigMinAggregateOutputType | null
    _max: CloudConfigMaxAggregateOutputType | null
  }

  type GetCloudConfigGroupByPayload<T extends CloudConfigGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<CloudConfigGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof CloudConfigGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], CloudConfigGroupByOutputType[P]>
            : GetScalarType<T[P], CloudConfigGroupByOutputType[P]>
        }
      >
    >


  export type CloudConfigSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    cloud_name?: boolean
    api_key?: boolean
    api_secret?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    setting?: boolean | CloudConfig$settingArgs<ExtArgs>
  }, ExtArgs["result"]["cloudConfig"]>

  export type CloudConfigSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    cloud_name?: boolean
    api_key?: boolean
    api_secret?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["cloudConfig"]>

  export type CloudConfigSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    cloud_name?: boolean
    api_key?: boolean
    api_secret?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["cloudConfig"]>

  export type CloudConfigSelectScalar = {
    id?: boolean
    cloud_name?: boolean
    api_key?: boolean
    api_secret?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type CloudConfigOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "cloud_name" | "api_key" | "api_secret" | "createdAt" | "updatedAt", ExtArgs["result"]["cloudConfig"]>
  export type CloudConfigInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    setting?: boolean | CloudConfig$settingArgs<ExtArgs>
  }
  export type CloudConfigIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}
  export type CloudConfigIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}

  export type $CloudConfigPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "CloudConfig"
    objects: {
      setting: Prisma.$SettingPayload<ExtArgs> | null
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      cloud_name: string
      api_key: string
      api_secret: string
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["cloudConfig"]>
    composites: {}
  }

  type CloudConfigGetPayload<S extends boolean | null | undefined | CloudConfigDefaultArgs> = $Result.GetResult<Prisma.$CloudConfigPayload, S>

  type CloudConfigCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<CloudConfigFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: CloudConfigCountAggregateInputType | true
    }

  export interface CloudConfigDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['CloudConfig'], meta: { name: 'CloudConfig' } }
    /**
     * Find zero or one CloudConfig that matches the filter.
     * @param {CloudConfigFindUniqueArgs} args - Arguments to find a CloudConfig
     * @example
     * // Get one CloudConfig
     * const cloudConfig = await prisma.cloudConfig.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends CloudConfigFindUniqueArgs>(args: SelectSubset<T, CloudConfigFindUniqueArgs<ExtArgs>>): Prisma__CloudConfigClient<$Result.GetResult<Prisma.$CloudConfigPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one CloudConfig that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {CloudConfigFindUniqueOrThrowArgs} args - Arguments to find a CloudConfig
     * @example
     * // Get one CloudConfig
     * const cloudConfig = await prisma.cloudConfig.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends CloudConfigFindUniqueOrThrowArgs>(args: SelectSubset<T, CloudConfigFindUniqueOrThrowArgs<ExtArgs>>): Prisma__CloudConfigClient<$Result.GetResult<Prisma.$CloudConfigPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first CloudConfig that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CloudConfigFindFirstArgs} args - Arguments to find a CloudConfig
     * @example
     * // Get one CloudConfig
     * const cloudConfig = await prisma.cloudConfig.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends CloudConfigFindFirstArgs>(args?: SelectSubset<T, CloudConfigFindFirstArgs<ExtArgs>>): Prisma__CloudConfigClient<$Result.GetResult<Prisma.$CloudConfigPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first CloudConfig that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CloudConfigFindFirstOrThrowArgs} args - Arguments to find a CloudConfig
     * @example
     * // Get one CloudConfig
     * const cloudConfig = await prisma.cloudConfig.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends CloudConfigFindFirstOrThrowArgs>(args?: SelectSubset<T, CloudConfigFindFirstOrThrowArgs<ExtArgs>>): Prisma__CloudConfigClient<$Result.GetResult<Prisma.$CloudConfigPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more CloudConfigs that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CloudConfigFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all CloudConfigs
     * const cloudConfigs = await prisma.cloudConfig.findMany()
     * 
     * // Get first 10 CloudConfigs
     * const cloudConfigs = await prisma.cloudConfig.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const cloudConfigWithIdOnly = await prisma.cloudConfig.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends CloudConfigFindManyArgs>(args?: SelectSubset<T, CloudConfigFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CloudConfigPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a CloudConfig.
     * @param {CloudConfigCreateArgs} args - Arguments to create a CloudConfig.
     * @example
     * // Create one CloudConfig
     * const CloudConfig = await prisma.cloudConfig.create({
     *   data: {
     *     // ... data to create a CloudConfig
     *   }
     * })
     * 
     */
    create<T extends CloudConfigCreateArgs>(args: SelectSubset<T, CloudConfigCreateArgs<ExtArgs>>): Prisma__CloudConfigClient<$Result.GetResult<Prisma.$CloudConfigPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many CloudConfigs.
     * @param {CloudConfigCreateManyArgs} args - Arguments to create many CloudConfigs.
     * @example
     * // Create many CloudConfigs
     * const cloudConfig = await prisma.cloudConfig.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends CloudConfigCreateManyArgs>(args?: SelectSubset<T, CloudConfigCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many CloudConfigs and returns the data saved in the database.
     * @param {CloudConfigCreateManyAndReturnArgs} args - Arguments to create many CloudConfigs.
     * @example
     * // Create many CloudConfigs
     * const cloudConfig = await prisma.cloudConfig.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many CloudConfigs and only return the `id`
     * const cloudConfigWithIdOnly = await prisma.cloudConfig.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends CloudConfigCreateManyAndReturnArgs>(args?: SelectSubset<T, CloudConfigCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CloudConfigPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a CloudConfig.
     * @param {CloudConfigDeleteArgs} args - Arguments to delete one CloudConfig.
     * @example
     * // Delete one CloudConfig
     * const CloudConfig = await prisma.cloudConfig.delete({
     *   where: {
     *     // ... filter to delete one CloudConfig
     *   }
     * })
     * 
     */
    delete<T extends CloudConfigDeleteArgs>(args: SelectSubset<T, CloudConfigDeleteArgs<ExtArgs>>): Prisma__CloudConfigClient<$Result.GetResult<Prisma.$CloudConfigPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one CloudConfig.
     * @param {CloudConfigUpdateArgs} args - Arguments to update one CloudConfig.
     * @example
     * // Update one CloudConfig
     * const cloudConfig = await prisma.cloudConfig.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends CloudConfigUpdateArgs>(args: SelectSubset<T, CloudConfigUpdateArgs<ExtArgs>>): Prisma__CloudConfigClient<$Result.GetResult<Prisma.$CloudConfigPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more CloudConfigs.
     * @param {CloudConfigDeleteManyArgs} args - Arguments to filter CloudConfigs to delete.
     * @example
     * // Delete a few CloudConfigs
     * const { count } = await prisma.cloudConfig.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends CloudConfigDeleteManyArgs>(args?: SelectSubset<T, CloudConfigDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more CloudConfigs.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CloudConfigUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many CloudConfigs
     * const cloudConfig = await prisma.cloudConfig.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends CloudConfigUpdateManyArgs>(args: SelectSubset<T, CloudConfigUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more CloudConfigs and returns the data updated in the database.
     * @param {CloudConfigUpdateManyAndReturnArgs} args - Arguments to update many CloudConfigs.
     * @example
     * // Update many CloudConfigs
     * const cloudConfig = await prisma.cloudConfig.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more CloudConfigs and only return the `id`
     * const cloudConfigWithIdOnly = await prisma.cloudConfig.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends CloudConfigUpdateManyAndReturnArgs>(args: SelectSubset<T, CloudConfigUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$CloudConfigPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one CloudConfig.
     * @param {CloudConfigUpsertArgs} args - Arguments to update or create a CloudConfig.
     * @example
     * // Update or create a CloudConfig
     * const cloudConfig = await prisma.cloudConfig.upsert({
     *   create: {
     *     // ... data to create a CloudConfig
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the CloudConfig we want to update
     *   }
     * })
     */
    upsert<T extends CloudConfigUpsertArgs>(args: SelectSubset<T, CloudConfigUpsertArgs<ExtArgs>>): Prisma__CloudConfigClient<$Result.GetResult<Prisma.$CloudConfigPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of CloudConfigs.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CloudConfigCountArgs} args - Arguments to filter CloudConfigs to count.
     * @example
     * // Count the number of CloudConfigs
     * const count = await prisma.cloudConfig.count({
     *   where: {
     *     // ... the filter for the CloudConfigs we want to count
     *   }
     * })
    **/
    count<T extends CloudConfigCountArgs>(
      args?: Subset<T, CloudConfigCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], CloudConfigCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a CloudConfig.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CloudConfigAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends CloudConfigAggregateArgs>(args: Subset<T, CloudConfigAggregateArgs>): Prisma.PrismaPromise<GetCloudConfigAggregateType<T>>

    /**
     * Group by CloudConfig.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CloudConfigGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends CloudConfigGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: CloudConfigGroupByArgs['orderBy'] }
        : { orderBy?: CloudConfigGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, CloudConfigGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetCloudConfigGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the CloudConfig model
   */
  readonly fields: CloudConfigFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for CloudConfig.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__CloudConfigClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    setting<T extends CloudConfig$settingArgs<ExtArgs> = {}>(args?: Subset<T, CloudConfig$settingArgs<ExtArgs>>): Prisma__SettingClient<$Result.GetResult<Prisma.$SettingPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the CloudConfig model
   */
  interface CloudConfigFieldRefs {
    readonly id: FieldRef<"CloudConfig", 'String'>
    readonly cloud_name: FieldRef<"CloudConfig", 'String'>
    readonly api_key: FieldRef<"CloudConfig", 'String'>
    readonly api_secret: FieldRef<"CloudConfig", 'String'>
    readonly createdAt: FieldRef<"CloudConfig", 'DateTime'>
    readonly updatedAt: FieldRef<"CloudConfig", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * CloudConfig findUnique
   */
  export type CloudConfigFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CloudConfig
     */
    select?: CloudConfigSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CloudConfig
     */
    omit?: CloudConfigOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CloudConfigInclude<ExtArgs> | null
    /**
     * Filter, which CloudConfig to fetch.
     */
    where: CloudConfigWhereUniqueInput
  }

  /**
   * CloudConfig findUniqueOrThrow
   */
  export type CloudConfigFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CloudConfig
     */
    select?: CloudConfigSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CloudConfig
     */
    omit?: CloudConfigOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CloudConfigInclude<ExtArgs> | null
    /**
     * Filter, which CloudConfig to fetch.
     */
    where: CloudConfigWhereUniqueInput
  }

  /**
   * CloudConfig findFirst
   */
  export type CloudConfigFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CloudConfig
     */
    select?: CloudConfigSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CloudConfig
     */
    omit?: CloudConfigOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CloudConfigInclude<ExtArgs> | null
    /**
     * Filter, which CloudConfig to fetch.
     */
    where?: CloudConfigWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of CloudConfigs to fetch.
     */
    orderBy?: CloudConfigOrderByWithRelationInput | CloudConfigOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for CloudConfigs.
     */
    cursor?: CloudConfigWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` CloudConfigs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` CloudConfigs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of CloudConfigs.
     */
    distinct?: CloudConfigScalarFieldEnum | CloudConfigScalarFieldEnum[]
  }

  /**
   * CloudConfig findFirstOrThrow
   */
  export type CloudConfigFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CloudConfig
     */
    select?: CloudConfigSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CloudConfig
     */
    omit?: CloudConfigOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CloudConfigInclude<ExtArgs> | null
    /**
     * Filter, which CloudConfig to fetch.
     */
    where?: CloudConfigWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of CloudConfigs to fetch.
     */
    orderBy?: CloudConfigOrderByWithRelationInput | CloudConfigOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for CloudConfigs.
     */
    cursor?: CloudConfigWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` CloudConfigs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` CloudConfigs.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of CloudConfigs.
     */
    distinct?: CloudConfigScalarFieldEnum | CloudConfigScalarFieldEnum[]
  }

  /**
   * CloudConfig findMany
   */
  export type CloudConfigFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CloudConfig
     */
    select?: CloudConfigSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CloudConfig
     */
    omit?: CloudConfigOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CloudConfigInclude<ExtArgs> | null
    /**
     * Filter, which CloudConfigs to fetch.
     */
    where?: CloudConfigWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of CloudConfigs to fetch.
     */
    orderBy?: CloudConfigOrderByWithRelationInput | CloudConfigOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing CloudConfigs.
     */
    cursor?: CloudConfigWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` CloudConfigs from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` CloudConfigs.
     */
    skip?: number
    distinct?: CloudConfigScalarFieldEnum | CloudConfigScalarFieldEnum[]
  }

  /**
   * CloudConfig create
   */
  export type CloudConfigCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CloudConfig
     */
    select?: CloudConfigSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CloudConfig
     */
    omit?: CloudConfigOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CloudConfigInclude<ExtArgs> | null
    /**
     * The data needed to create a CloudConfig.
     */
    data: XOR<CloudConfigCreateInput, CloudConfigUncheckedCreateInput>
  }

  /**
   * CloudConfig createMany
   */
  export type CloudConfigCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many CloudConfigs.
     */
    data: CloudConfigCreateManyInput | CloudConfigCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * CloudConfig createManyAndReturn
   */
  export type CloudConfigCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CloudConfig
     */
    select?: CloudConfigSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the CloudConfig
     */
    omit?: CloudConfigOmit<ExtArgs> | null
    /**
     * The data used to create many CloudConfigs.
     */
    data: CloudConfigCreateManyInput | CloudConfigCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * CloudConfig update
   */
  export type CloudConfigUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CloudConfig
     */
    select?: CloudConfigSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CloudConfig
     */
    omit?: CloudConfigOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CloudConfigInclude<ExtArgs> | null
    /**
     * The data needed to update a CloudConfig.
     */
    data: XOR<CloudConfigUpdateInput, CloudConfigUncheckedUpdateInput>
    /**
     * Choose, which CloudConfig to update.
     */
    where: CloudConfigWhereUniqueInput
  }

  /**
   * CloudConfig updateMany
   */
  export type CloudConfigUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update CloudConfigs.
     */
    data: XOR<CloudConfigUpdateManyMutationInput, CloudConfigUncheckedUpdateManyInput>
    /**
     * Filter which CloudConfigs to update
     */
    where?: CloudConfigWhereInput
    /**
     * Limit how many CloudConfigs to update.
     */
    limit?: number
  }

  /**
   * CloudConfig updateManyAndReturn
   */
  export type CloudConfigUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CloudConfig
     */
    select?: CloudConfigSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the CloudConfig
     */
    omit?: CloudConfigOmit<ExtArgs> | null
    /**
     * The data used to update CloudConfigs.
     */
    data: XOR<CloudConfigUpdateManyMutationInput, CloudConfigUncheckedUpdateManyInput>
    /**
     * Filter which CloudConfigs to update
     */
    where?: CloudConfigWhereInput
    /**
     * Limit how many CloudConfigs to update.
     */
    limit?: number
  }

  /**
   * CloudConfig upsert
   */
  export type CloudConfigUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CloudConfig
     */
    select?: CloudConfigSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CloudConfig
     */
    omit?: CloudConfigOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CloudConfigInclude<ExtArgs> | null
    /**
     * The filter to search for the CloudConfig to update in case it exists.
     */
    where: CloudConfigWhereUniqueInput
    /**
     * In case the CloudConfig found by the `where` argument doesn't exist, create a new CloudConfig with this data.
     */
    create: XOR<CloudConfigCreateInput, CloudConfigUncheckedCreateInput>
    /**
     * In case the CloudConfig was found with the provided `where` argument, update it with this data.
     */
    update: XOR<CloudConfigUpdateInput, CloudConfigUncheckedUpdateInput>
  }

  /**
   * CloudConfig delete
   */
  export type CloudConfigDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CloudConfig
     */
    select?: CloudConfigSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CloudConfig
     */
    omit?: CloudConfigOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CloudConfigInclude<ExtArgs> | null
    /**
     * Filter which CloudConfig to delete.
     */
    where: CloudConfigWhereUniqueInput
  }

  /**
   * CloudConfig deleteMany
   */
  export type CloudConfigDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which CloudConfigs to delete
     */
    where?: CloudConfigWhereInput
    /**
     * Limit how many CloudConfigs to delete.
     */
    limit?: number
  }

  /**
   * CloudConfig.setting
   */
  export type CloudConfig$settingArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Setting
     */
    select?: SettingSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Setting
     */
    omit?: SettingOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SettingInclude<ExtArgs> | null
    where?: SettingWhereInput
  }

  /**
   * CloudConfig without action
   */
  export type CloudConfigDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CloudConfig
     */
    select?: CloudConfigSelect<ExtArgs> | null
    /**
     * Omit specific fields from the CloudConfig
     */
    omit?: CloudConfigOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: CloudConfigInclude<ExtArgs> | null
  }


  /**
   * Model otp
   */

  export type AggregateOtp = {
    _count: OtpCountAggregateOutputType | null
    _min: OtpMinAggregateOutputType | null
    _max: OtpMaxAggregateOutputType | null
  }

  export type OtpMinAggregateOutputType = {
    id: string | null
    identifier: string | null
    action: string | null
    otp: string | null
    createdAt: Date | null
  }

  export type OtpMaxAggregateOutputType = {
    id: string | null
    identifier: string | null
    action: string | null
    otp: string | null
    createdAt: Date | null
  }

  export type OtpCountAggregateOutputType = {
    id: number
    identifier: number
    action: number
    otp: number
    createdAt: number
    _all: number
  }


  export type OtpMinAggregateInputType = {
    id?: true
    identifier?: true
    action?: true
    otp?: true
    createdAt?: true
  }

  export type OtpMaxAggregateInputType = {
    id?: true
    identifier?: true
    action?: true
    otp?: true
    createdAt?: true
  }

  export type OtpCountAggregateInputType = {
    id?: true
    identifier?: true
    action?: true
    otp?: true
    createdAt?: true
    _all?: true
  }

  export type OtpAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which otp to aggregate.
     */
    where?: otpWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of otps to fetch.
     */
    orderBy?: otpOrderByWithRelationInput | otpOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: otpWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` otps from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` otps.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned otps
    **/
    _count?: true | OtpCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: OtpMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: OtpMaxAggregateInputType
  }

  export type GetOtpAggregateType<T extends OtpAggregateArgs> = {
        [P in keyof T & keyof AggregateOtp]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateOtp[P]>
      : GetScalarType<T[P], AggregateOtp[P]>
  }




  export type otpGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: otpWhereInput
    orderBy?: otpOrderByWithAggregationInput | otpOrderByWithAggregationInput[]
    by: OtpScalarFieldEnum[] | OtpScalarFieldEnum
    having?: otpScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: OtpCountAggregateInputType | true
    _min?: OtpMinAggregateInputType
    _max?: OtpMaxAggregateInputType
  }

  export type OtpGroupByOutputType = {
    id: string
    identifier: string
    action: string
    otp: string
    createdAt: Date
    _count: OtpCountAggregateOutputType | null
    _min: OtpMinAggregateOutputType | null
    _max: OtpMaxAggregateOutputType | null
  }

  type GetOtpGroupByPayload<T extends otpGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<OtpGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof OtpGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], OtpGroupByOutputType[P]>
            : GetScalarType<T[P], OtpGroupByOutputType[P]>
        }
      >
    >


  export type otpSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    identifier?: boolean
    action?: boolean
    otp?: boolean
    createdAt?: boolean
  }, ExtArgs["result"]["otp"]>

  export type otpSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    identifier?: boolean
    action?: boolean
    otp?: boolean
    createdAt?: boolean
  }, ExtArgs["result"]["otp"]>

  export type otpSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    identifier?: boolean
    action?: boolean
    otp?: boolean
    createdAt?: boolean
  }, ExtArgs["result"]["otp"]>

  export type otpSelectScalar = {
    id?: boolean
    identifier?: boolean
    action?: boolean
    otp?: boolean
    createdAt?: boolean
  }

  export type otpOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "identifier" | "action" | "otp" | "createdAt", ExtArgs["result"]["otp"]>

  export type $otpPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "otp"
    objects: {}
    scalars: $Extensions.GetPayloadResult<{
      id: string
      identifier: string
      action: string
      otp: string
      createdAt: Date
    }, ExtArgs["result"]["otp"]>
    composites: {}
  }

  type otpGetPayload<S extends boolean | null | undefined | otpDefaultArgs> = $Result.GetResult<Prisma.$otpPayload, S>

  type otpCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<otpFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: OtpCountAggregateInputType | true
    }

  export interface otpDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['otp'], meta: { name: 'otp' } }
    /**
     * Find zero or one Otp that matches the filter.
     * @param {otpFindUniqueArgs} args - Arguments to find a Otp
     * @example
     * // Get one Otp
     * const otp = await prisma.otp.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends otpFindUniqueArgs>(args: SelectSubset<T, otpFindUniqueArgs<ExtArgs>>): Prisma__otpClient<$Result.GetResult<Prisma.$otpPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Otp that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {otpFindUniqueOrThrowArgs} args - Arguments to find a Otp
     * @example
     * // Get one Otp
     * const otp = await prisma.otp.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends otpFindUniqueOrThrowArgs>(args: SelectSubset<T, otpFindUniqueOrThrowArgs<ExtArgs>>): Prisma__otpClient<$Result.GetResult<Prisma.$otpPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Otp that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {otpFindFirstArgs} args - Arguments to find a Otp
     * @example
     * // Get one Otp
     * const otp = await prisma.otp.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends otpFindFirstArgs>(args?: SelectSubset<T, otpFindFirstArgs<ExtArgs>>): Prisma__otpClient<$Result.GetResult<Prisma.$otpPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Otp that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {otpFindFirstOrThrowArgs} args - Arguments to find a Otp
     * @example
     * // Get one Otp
     * const otp = await prisma.otp.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends otpFindFirstOrThrowArgs>(args?: SelectSubset<T, otpFindFirstOrThrowArgs<ExtArgs>>): Prisma__otpClient<$Result.GetResult<Prisma.$otpPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Otps that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {otpFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Otps
     * const otps = await prisma.otp.findMany()
     * 
     * // Get first 10 Otps
     * const otps = await prisma.otp.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const otpWithIdOnly = await prisma.otp.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends otpFindManyArgs>(args?: SelectSubset<T, otpFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$otpPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Otp.
     * @param {otpCreateArgs} args - Arguments to create a Otp.
     * @example
     * // Create one Otp
     * const Otp = await prisma.otp.create({
     *   data: {
     *     // ... data to create a Otp
     *   }
     * })
     * 
     */
    create<T extends otpCreateArgs>(args: SelectSubset<T, otpCreateArgs<ExtArgs>>): Prisma__otpClient<$Result.GetResult<Prisma.$otpPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Otps.
     * @param {otpCreateManyArgs} args - Arguments to create many Otps.
     * @example
     * // Create many Otps
     * const otp = await prisma.otp.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends otpCreateManyArgs>(args?: SelectSubset<T, otpCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Otps and returns the data saved in the database.
     * @param {otpCreateManyAndReturnArgs} args - Arguments to create many Otps.
     * @example
     * // Create many Otps
     * const otp = await prisma.otp.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Otps and only return the `id`
     * const otpWithIdOnly = await prisma.otp.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends otpCreateManyAndReturnArgs>(args?: SelectSubset<T, otpCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$otpPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Otp.
     * @param {otpDeleteArgs} args - Arguments to delete one Otp.
     * @example
     * // Delete one Otp
     * const Otp = await prisma.otp.delete({
     *   where: {
     *     // ... filter to delete one Otp
     *   }
     * })
     * 
     */
    delete<T extends otpDeleteArgs>(args: SelectSubset<T, otpDeleteArgs<ExtArgs>>): Prisma__otpClient<$Result.GetResult<Prisma.$otpPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Otp.
     * @param {otpUpdateArgs} args - Arguments to update one Otp.
     * @example
     * // Update one Otp
     * const otp = await prisma.otp.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends otpUpdateArgs>(args: SelectSubset<T, otpUpdateArgs<ExtArgs>>): Prisma__otpClient<$Result.GetResult<Prisma.$otpPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Otps.
     * @param {otpDeleteManyArgs} args - Arguments to filter Otps to delete.
     * @example
     * // Delete a few Otps
     * const { count } = await prisma.otp.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends otpDeleteManyArgs>(args?: SelectSubset<T, otpDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Otps.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {otpUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Otps
     * const otp = await prisma.otp.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends otpUpdateManyArgs>(args: SelectSubset<T, otpUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Otps and returns the data updated in the database.
     * @param {otpUpdateManyAndReturnArgs} args - Arguments to update many Otps.
     * @example
     * // Update many Otps
     * const otp = await prisma.otp.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Otps and only return the `id`
     * const otpWithIdOnly = await prisma.otp.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends otpUpdateManyAndReturnArgs>(args: SelectSubset<T, otpUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$otpPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Otp.
     * @param {otpUpsertArgs} args - Arguments to update or create a Otp.
     * @example
     * // Update or create a Otp
     * const otp = await prisma.otp.upsert({
     *   create: {
     *     // ... data to create a Otp
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Otp we want to update
     *   }
     * })
     */
    upsert<T extends otpUpsertArgs>(args: SelectSubset<T, otpUpsertArgs<ExtArgs>>): Prisma__otpClient<$Result.GetResult<Prisma.$otpPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Otps.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {otpCountArgs} args - Arguments to filter Otps to count.
     * @example
     * // Count the number of Otps
     * const count = await prisma.otp.count({
     *   where: {
     *     // ... the filter for the Otps we want to count
     *   }
     * })
    **/
    count<T extends otpCountArgs>(
      args?: Subset<T, otpCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], OtpCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Otp.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {OtpAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends OtpAggregateArgs>(args: Subset<T, OtpAggregateArgs>): Prisma.PrismaPromise<GetOtpAggregateType<T>>

    /**
     * Group by Otp.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {otpGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends otpGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: otpGroupByArgs['orderBy'] }
        : { orderBy?: otpGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, otpGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetOtpGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the otp model
   */
  readonly fields: otpFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for otp.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__otpClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the otp model
   */
  interface otpFieldRefs {
    readonly id: FieldRef<"otp", 'String'>
    readonly identifier: FieldRef<"otp", 'String'>
    readonly action: FieldRef<"otp", 'String'>
    readonly otp: FieldRef<"otp", 'String'>
    readonly createdAt: FieldRef<"otp", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * otp findUnique
   */
  export type otpFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the otp
     */
    select?: otpSelect<ExtArgs> | null
    /**
     * Omit specific fields from the otp
     */
    omit?: otpOmit<ExtArgs> | null
    /**
     * Filter, which otp to fetch.
     */
    where: otpWhereUniqueInput
  }

  /**
   * otp findUniqueOrThrow
   */
  export type otpFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the otp
     */
    select?: otpSelect<ExtArgs> | null
    /**
     * Omit specific fields from the otp
     */
    omit?: otpOmit<ExtArgs> | null
    /**
     * Filter, which otp to fetch.
     */
    where: otpWhereUniqueInput
  }

  /**
   * otp findFirst
   */
  export type otpFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the otp
     */
    select?: otpSelect<ExtArgs> | null
    /**
     * Omit specific fields from the otp
     */
    omit?: otpOmit<ExtArgs> | null
    /**
     * Filter, which otp to fetch.
     */
    where?: otpWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of otps to fetch.
     */
    orderBy?: otpOrderByWithRelationInput | otpOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for otps.
     */
    cursor?: otpWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` otps from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` otps.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of otps.
     */
    distinct?: OtpScalarFieldEnum | OtpScalarFieldEnum[]
  }

  /**
   * otp findFirstOrThrow
   */
  export type otpFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the otp
     */
    select?: otpSelect<ExtArgs> | null
    /**
     * Omit specific fields from the otp
     */
    omit?: otpOmit<ExtArgs> | null
    /**
     * Filter, which otp to fetch.
     */
    where?: otpWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of otps to fetch.
     */
    orderBy?: otpOrderByWithRelationInput | otpOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for otps.
     */
    cursor?: otpWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` otps from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` otps.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of otps.
     */
    distinct?: OtpScalarFieldEnum | OtpScalarFieldEnum[]
  }

  /**
   * otp findMany
   */
  export type otpFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the otp
     */
    select?: otpSelect<ExtArgs> | null
    /**
     * Omit specific fields from the otp
     */
    omit?: otpOmit<ExtArgs> | null
    /**
     * Filter, which otps to fetch.
     */
    where?: otpWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of otps to fetch.
     */
    orderBy?: otpOrderByWithRelationInput | otpOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing otps.
     */
    cursor?: otpWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` otps from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` otps.
     */
    skip?: number
    distinct?: OtpScalarFieldEnum | OtpScalarFieldEnum[]
  }

  /**
   * otp create
   */
  export type otpCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the otp
     */
    select?: otpSelect<ExtArgs> | null
    /**
     * Omit specific fields from the otp
     */
    omit?: otpOmit<ExtArgs> | null
    /**
     * The data needed to create a otp.
     */
    data: XOR<otpCreateInput, otpUncheckedCreateInput>
  }

  /**
   * otp createMany
   */
  export type otpCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many otps.
     */
    data: otpCreateManyInput | otpCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * otp createManyAndReturn
   */
  export type otpCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the otp
     */
    select?: otpSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the otp
     */
    omit?: otpOmit<ExtArgs> | null
    /**
     * The data used to create many otps.
     */
    data: otpCreateManyInput | otpCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * otp update
   */
  export type otpUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the otp
     */
    select?: otpSelect<ExtArgs> | null
    /**
     * Omit specific fields from the otp
     */
    omit?: otpOmit<ExtArgs> | null
    /**
     * The data needed to update a otp.
     */
    data: XOR<otpUpdateInput, otpUncheckedUpdateInput>
    /**
     * Choose, which otp to update.
     */
    where: otpWhereUniqueInput
  }

  /**
   * otp updateMany
   */
  export type otpUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update otps.
     */
    data: XOR<otpUpdateManyMutationInput, otpUncheckedUpdateManyInput>
    /**
     * Filter which otps to update
     */
    where?: otpWhereInput
    /**
     * Limit how many otps to update.
     */
    limit?: number
  }

  /**
   * otp updateManyAndReturn
   */
  export type otpUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the otp
     */
    select?: otpSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the otp
     */
    omit?: otpOmit<ExtArgs> | null
    /**
     * The data used to update otps.
     */
    data: XOR<otpUpdateManyMutationInput, otpUncheckedUpdateManyInput>
    /**
     * Filter which otps to update
     */
    where?: otpWhereInput
    /**
     * Limit how many otps to update.
     */
    limit?: number
  }

  /**
   * otp upsert
   */
  export type otpUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the otp
     */
    select?: otpSelect<ExtArgs> | null
    /**
     * Omit specific fields from the otp
     */
    omit?: otpOmit<ExtArgs> | null
    /**
     * The filter to search for the otp to update in case it exists.
     */
    where: otpWhereUniqueInput
    /**
     * In case the otp found by the `where` argument doesn't exist, create a new otp with this data.
     */
    create: XOR<otpCreateInput, otpUncheckedCreateInput>
    /**
     * In case the otp was found with the provided `where` argument, update it with this data.
     */
    update: XOR<otpUpdateInput, otpUncheckedUpdateInput>
  }

  /**
   * otp delete
   */
  export type otpDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the otp
     */
    select?: otpSelect<ExtArgs> | null
    /**
     * Omit specific fields from the otp
     */
    omit?: otpOmit<ExtArgs> | null
    /**
     * Filter which otp to delete.
     */
    where: otpWhereUniqueInput
  }

  /**
   * otp deleteMany
   */
  export type otpDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which otps to delete
     */
    where?: otpWhereInput
    /**
     * Limit how many otps to delete.
     */
    limit?: number
  }

  /**
   * otp without action
   */
  export type otpDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the otp
     */
    select?: otpSelect<ExtArgs> | null
    /**
     * Omit specific fields from the otp
     */
    omit?: otpOmit<ExtArgs> | null
  }


  /**
   * Enums
   */

  export const TransactionIsolationLevel: {
    ReadUncommitted: 'ReadUncommitted',
    ReadCommitted: 'ReadCommitted',
    RepeatableRead: 'RepeatableRead',
    Serializable: 'Serializable'
  };

  export type TransactionIsolationLevel = (typeof TransactionIsolationLevel)[keyof typeof TransactionIsolationLevel]


  export const UserScalarFieldEnum: {
    id: 'id',
    name: 'name',
    email: 'email',
    password: 'password',
    image: 'image',
    phone: 'phone',
    role: 'role',
    country: 'country',
    city: 'city',
    state: 'state',
    zip_code: 'zip_code',
    address: 'address',
    about: 'about',
    is_deleted: 'is_deleted',
    otp: 'otp'
  };

  export type UserScalarFieldEnum = (typeof UserScalarFieldEnum)[keyof typeof UserScalarFieldEnum]


  export const SettingScalarFieldEnum: {
    id: 'id',
    site_name: 'site_name',
    site_email: 'site_email',
    site_phone: 'site_phone',
    site_logo: 'site_logo',
    site_address: 'site_address',
    site_description: 'site_description',
    site_footer: 'site_footer',
    client_side_url: 'client_side_url',
    server_side_url: 'server_side_url',
    otp_verification_type: 'otp_verification_type',
    email_config_id: 'email_config_id',
    cloud_config_id: 'cloud_config_id',
    stripe: 'stripe',
    paypal: 'paypal',
    razorpay: 'razorpay',
    mollie: 'mollie',
    social_media_link: 'social_media_link',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type SettingScalarFieldEnum = (typeof SettingScalarFieldEnum)[keyof typeof SettingScalarFieldEnum]


  export const EmailConfigScalarFieldEnum: {
    id: 'id',
    resend_api_key: 'resend_api_key',
    resend_email: 'resend_email',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type EmailConfigScalarFieldEnum = (typeof EmailConfigScalarFieldEnum)[keyof typeof EmailConfigScalarFieldEnum]


  export const CloudConfigScalarFieldEnum: {
    id: 'id',
    cloud_name: 'cloud_name',
    api_key: 'api_key',
    api_secret: 'api_secret',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type CloudConfigScalarFieldEnum = (typeof CloudConfigScalarFieldEnum)[keyof typeof CloudConfigScalarFieldEnum]


  export const OtpScalarFieldEnum: {
    id: 'id',
    identifier: 'identifier',
    action: 'action',
    otp: 'otp',
    createdAt: 'createdAt'
  };

  export type OtpScalarFieldEnum = (typeof OtpScalarFieldEnum)[keyof typeof OtpScalarFieldEnum]


  export const SortOrder: {
    asc: 'asc',
    desc: 'desc'
  };

  export type SortOrder = (typeof SortOrder)[keyof typeof SortOrder]


  export const NullableJsonNullValueInput: {
    DbNull: typeof DbNull,
    JsonNull: typeof JsonNull
  };

  export type NullableJsonNullValueInput = (typeof NullableJsonNullValueInput)[keyof typeof NullableJsonNullValueInput]


  export const QueryMode: {
    default: 'default',
    insensitive: 'insensitive'
  };

  export type QueryMode = (typeof QueryMode)[keyof typeof QueryMode]


  export const NullsOrder: {
    first: 'first',
    last: 'last'
  };

  export type NullsOrder = (typeof NullsOrder)[keyof typeof NullsOrder]


  export const JsonNullValueFilter: {
    DbNull: typeof DbNull,
    JsonNull: typeof JsonNull,
    AnyNull: typeof AnyNull
  };

  export type JsonNullValueFilter = (typeof JsonNullValueFilter)[keyof typeof JsonNullValueFilter]


  /**
   * Field references
   */


  /**
   * Reference to a field of type 'String'
   */
  export type StringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String'>
    


  /**
   * Reference to a field of type 'String[]'
   */
  export type ListStringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String[]'>
    


  /**
   * Reference to a field of type 'Role'
   */
  export type EnumRoleFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Role'>
    


  /**
   * Reference to a field of type 'Role[]'
   */
  export type ListEnumRoleFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Role[]'>
    


  /**
   * Reference to a field of type 'Boolean'
   */
  export type BooleanFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Boolean'>
    


  /**
   * Reference to a field of type 'Json'
   */
  export type JsonFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Json'>
    


  /**
   * Reference to a field of type 'QueryMode'
   */
  export type EnumQueryModeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'QueryMode'>
    


  /**
   * Reference to a field of type 'DateTime'
   */
  export type DateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime'>
    


  /**
   * Reference to a field of type 'DateTime[]'
   */
  export type ListDateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime[]'>
    


  /**
   * Reference to a field of type 'Int'
   */
  export type IntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int'>
    


  /**
   * Reference to a field of type 'Int[]'
   */
  export type ListIntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int[]'>
    
  /**
   * Deep Input Types
   */


  export type userWhereInput = {
    AND?: userWhereInput | userWhereInput[]
    OR?: userWhereInput[]
    NOT?: userWhereInput | userWhereInput[]
    id?: StringFilter<"user"> | string
    name?: StringNullableFilter<"user"> | string | null
    email?: StringFilter<"user"> | string
    password?: StringFilter<"user"> | string
    image?: StringNullableFilter<"user"> | string | null
    phone?: StringNullableFilter<"user"> | string | null
    role?: EnumRoleFilter<"user"> | $Enums.Role
    country?: StringNullableFilter<"user"> | string | null
    city?: StringNullableFilter<"user"> | string | null
    state?: StringNullableFilter<"user"> | string | null
    zip_code?: StringNullableFilter<"user"> | string | null
    address?: StringNullableFilter<"user"> | string | null
    about?: StringNullableFilter<"user"> | string | null
    is_deleted?: BoolNullableFilter<"user"> | boolean | null
    otp?: StringFilter<"user"> | string
  }

  export type userOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrderInput | SortOrder
    email?: SortOrder
    password?: SortOrder
    image?: SortOrderInput | SortOrder
    phone?: SortOrderInput | SortOrder
    role?: SortOrder
    country?: SortOrderInput | SortOrder
    city?: SortOrderInput | SortOrder
    state?: SortOrderInput | SortOrder
    zip_code?: SortOrderInput | SortOrder
    address?: SortOrderInput | SortOrder
    about?: SortOrderInput | SortOrder
    is_deleted?: SortOrderInput | SortOrder
    otp?: SortOrder
  }

  export type userWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    email?: string
    AND?: userWhereInput | userWhereInput[]
    OR?: userWhereInput[]
    NOT?: userWhereInput | userWhereInput[]
    name?: StringNullableFilter<"user"> | string | null
    password?: StringFilter<"user"> | string
    image?: StringNullableFilter<"user"> | string | null
    phone?: StringNullableFilter<"user"> | string | null
    role?: EnumRoleFilter<"user"> | $Enums.Role
    country?: StringNullableFilter<"user"> | string | null
    city?: StringNullableFilter<"user"> | string | null
    state?: StringNullableFilter<"user"> | string | null
    zip_code?: StringNullableFilter<"user"> | string | null
    address?: StringNullableFilter<"user"> | string | null
    about?: StringNullableFilter<"user"> | string | null
    is_deleted?: BoolNullableFilter<"user"> | boolean | null
    otp?: StringFilter<"user"> | string
  }, "id" | "email">

  export type userOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrderInput | SortOrder
    email?: SortOrder
    password?: SortOrder
    image?: SortOrderInput | SortOrder
    phone?: SortOrderInput | SortOrder
    role?: SortOrder
    country?: SortOrderInput | SortOrder
    city?: SortOrderInput | SortOrder
    state?: SortOrderInput | SortOrder
    zip_code?: SortOrderInput | SortOrder
    address?: SortOrderInput | SortOrder
    about?: SortOrderInput | SortOrder
    is_deleted?: SortOrderInput | SortOrder
    otp?: SortOrder
    _count?: userCountOrderByAggregateInput
    _max?: userMaxOrderByAggregateInput
    _min?: userMinOrderByAggregateInput
  }

  export type userScalarWhereWithAggregatesInput = {
    AND?: userScalarWhereWithAggregatesInput | userScalarWhereWithAggregatesInput[]
    OR?: userScalarWhereWithAggregatesInput[]
    NOT?: userScalarWhereWithAggregatesInput | userScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"user"> | string
    name?: StringNullableWithAggregatesFilter<"user"> | string | null
    email?: StringWithAggregatesFilter<"user"> | string
    password?: StringWithAggregatesFilter<"user"> | string
    image?: StringNullableWithAggregatesFilter<"user"> | string | null
    phone?: StringNullableWithAggregatesFilter<"user"> | string | null
    role?: EnumRoleWithAggregatesFilter<"user"> | $Enums.Role
    country?: StringNullableWithAggregatesFilter<"user"> | string | null
    city?: StringNullableWithAggregatesFilter<"user"> | string | null
    state?: StringNullableWithAggregatesFilter<"user"> | string | null
    zip_code?: StringNullableWithAggregatesFilter<"user"> | string | null
    address?: StringNullableWithAggregatesFilter<"user"> | string | null
    about?: StringNullableWithAggregatesFilter<"user"> | string | null
    is_deleted?: BoolNullableWithAggregatesFilter<"user"> | boolean | null
    otp?: StringWithAggregatesFilter<"user"> | string
  }

  export type SettingWhereInput = {
    AND?: SettingWhereInput | SettingWhereInput[]
    OR?: SettingWhereInput[]
    NOT?: SettingWhereInput | SettingWhereInput[]
    id?: StringFilter<"Setting"> | string
    site_name?: StringNullableFilter<"Setting"> | string | null
    site_email?: StringNullableFilter<"Setting"> | string | null
    site_phone?: StringNullableFilter<"Setting"> | string | null
    site_logo?: StringNullableFilter<"Setting"> | string | null
    site_address?: StringNullableFilter<"Setting"> | string | null
    site_description?: StringNullableFilter<"Setting"> | string | null
    site_footer?: StringNullableFilter<"Setting"> | string | null
    client_side_url?: StringNullableFilter<"Setting"> | string | null
    server_side_url?: StringNullableFilter<"Setting"> | string | null
    otp_verification_type?: StringNullableFilter<"Setting"> | string | null
    email_config_id?: StringNullableFilter<"Setting"> | string | null
    cloud_config_id?: StringNullableFilter<"Setting"> | string | null
    stripe?: JsonNullableFilter<"Setting">
    paypal?: JsonNullableFilter<"Setting">
    razorpay?: JsonNullableFilter<"Setting">
    mollie?: JsonNullableFilter<"Setting">
    social_media_link?: JsonNullableFilter<"Setting">
    createdAt?: DateTimeFilter<"Setting"> | Date | string
    updatedAt?: DateTimeFilter<"Setting"> | Date | string
    email_config?: XOR<EmailConfigNullableScalarRelationFilter, EmailConfigWhereInput> | null
    cloud_config?: XOR<CloudConfigNullableScalarRelationFilter, CloudConfigWhereInput> | null
  }

  export type SettingOrderByWithRelationInput = {
    id?: SortOrder
    site_name?: SortOrderInput | SortOrder
    site_email?: SortOrderInput | SortOrder
    site_phone?: SortOrderInput | SortOrder
    site_logo?: SortOrderInput | SortOrder
    site_address?: SortOrderInput | SortOrder
    site_description?: SortOrderInput | SortOrder
    site_footer?: SortOrderInput | SortOrder
    client_side_url?: SortOrderInput | SortOrder
    server_side_url?: SortOrderInput | SortOrder
    otp_verification_type?: SortOrderInput | SortOrder
    email_config_id?: SortOrderInput | SortOrder
    cloud_config_id?: SortOrderInput | SortOrder
    stripe?: SortOrderInput | SortOrder
    paypal?: SortOrderInput | SortOrder
    razorpay?: SortOrderInput | SortOrder
    mollie?: SortOrderInput | SortOrder
    social_media_link?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    email_config?: EmailConfigOrderByWithRelationInput
    cloud_config?: CloudConfigOrderByWithRelationInput
  }

  export type SettingWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    email_config_id?: string
    cloud_config_id?: string
    AND?: SettingWhereInput | SettingWhereInput[]
    OR?: SettingWhereInput[]
    NOT?: SettingWhereInput | SettingWhereInput[]
    site_name?: StringNullableFilter<"Setting"> | string | null
    site_email?: StringNullableFilter<"Setting"> | string | null
    site_phone?: StringNullableFilter<"Setting"> | string | null
    site_logo?: StringNullableFilter<"Setting"> | string | null
    site_address?: StringNullableFilter<"Setting"> | string | null
    site_description?: StringNullableFilter<"Setting"> | string | null
    site_footer?: StringNullableFilter<"Setting"> | string | null
    client_side_url?: StringNullableFilter<"Setting"> | string | null
    server_side_url?: StringNullableFilter<"Setting"> | string | null
    otp_verification_type?: StringNullableFilter<"Setting"> | string | null
    stripe?: JsonNullableFilter<"Setting">
    paypal?: JsonNullableFilter<"Setting">
    razorpay?: JsonNullableFilter<"Setting">
    mollie?: JsonNullableFilter<"Setting">
    social_media_link?: JsonNullableFilter<"Setting">
    createdAt?: DateTimeFilter<"Setting"> | Date | string
    updatedAt?: DateTimeFilter<"Setting"> | Date | string
    email_config?: XOR<EmailConfigNullableScalarRelationFilter, EmailConfigWhereInput> | null
    cloud_config?: XOR<CloudConfigNullableScalarRelationFilter, CloudConfigWhereInput> | null
  }, "id" | "email_config_id" | "cloud_config_id">

  export type SettingOrderByWithAggregationInput = {
    id?: SortOrder
    site_name?: SortOrderInput | SortOrder
    site_email?: SortOrderInput | SortOrder
    site_phone?: SortOrderInput | SortOrder
    site_logo?: SortOrderInput | SortOrder
    site_address?: SortOrderInput | SortOrder
    site_description?: SortOrderInput | SortOrder
    site_footer?: SortOrderInput | SortOrder
    client_side_url?: SortOrderInput | SortOrder
    server_side_url?: SortOrderInput | SortOrder
    otp_verification_type?: SortOrderInput | SortOrder
    email_config_id?: SortOrderInput | SortOrder
    cloud_config_id?: SortOrderInput | SortOrder
    stripe?: SortOrderInput | SortOrder
    paypal?: SortOrderInput | SortOrder
    razorpay?: SortOrderInput | SortOrder
    mollie?: SortOrderInput | SortOrder
    social_media_link?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: SettingCountOrderByAggregateInput
    _max?: SettingMaxOrderByAggregateInput
    _min?: SettingMinOrderByAggregateInput
  }

  export type SettingScalarWhereWithAggregatesInput = {
    AND?: SettingScalarWhereWithAggregatesInput | SettingScalarWhereWithAggregatesInput[]
    OR?: SettingScalarWhereWithAggregatesInput[]
    NOT?: SettingScalarWhereWithAggregatesInput | SettingScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Setting"> | string
    site_name?: StringNullableWithAggregatesFilter<"Setting"> | string | null
    site_email?: StringNullableWithAggregatesFilter<"Setting"> | string | null
    site_phone?: StringNullableWithAggregatesFilter<"Setting"> | string | null
    site_logo?: StringNullableWithAggregatesFilter<"Setting"> | string | null
    site_address?: StringNullableWithAggregatesFilter<"Setting"> | string | null
    site_description?: StringNullableWithAggregatesFilter<"Setting"> | string | null
    site_footer?: StringNullableWithAggregatesFilter<"Setting"> | string | null
    client_side_url?: StringNullableWithAggregatesFilter<"Setting"> | string | null
    server_side_url?: StringNullableWithAggregatesFilter<"Setting"> | string | null
    otp_verification_type?: StringNullableWithAggregatesFilter<"Setting"> | string | null
    email_config_id?: StringNullableWithAggregatesFilter<"Setting"> | string | null
    cloud_config_id?: StringNullableWithAggregatesFilter<"Setting"> | string | null
    stripe?: JsonNullableWithAggregatesFilter<"Setting">
    paypal?: JsonNullableWithAggregatesFilter<"Setting">
    razorpay?: JsonNullableWithAggregatesFilter<"Setting">
    mollie?: JsonNullableWithAggregatesFilter<"Setting">
    social_media_link?: JsonNullableWithAggregatesFilter<"Setting">
    createdAt?: DateTimeWithAggregatesFilter<"Setting"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"Setting"> | Date | string
  }

  export type EmailConfigWhereInput = {
    AND?: EmailConfigWhereInput | EmailConfigWhereInput[]
    OR?: EmailConfigWhereInput[]
    NOT?: EmailConfigWhereInput | EmailConfigWhereInput[]
    id?: StringFilter<"EmailConfig"> | string
    resend_api_key?: StringFilter<"EmailConfig"> | string
    resend_email?: StringFilter<"EmailConfig"> | string
    createdAt?: DateTimeFilter<"EmailConfig"> | Date | string
    updatedAt?: DateTimeFilter<"EmailConfig"> | Date | string
    setting?: XOR<SettingNullableScalarRelationFilter, SettingWhereInput> | null
  }

  export type EmailConfigOrderByWithRelationInput = {
    id?: SortOrder
    resend_api_key?: SortOrder
    resend_email?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    setting?: SettingOrderByWithRelationInput
  }

  export type EmailConfigWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: EmailConfigWhereInput | EmailConfigWhereInput[]
    OR?: EmailConfigWhereInput[]
    NOT?: EmailConfigWhereInput | EmailConfigWhereInput[]
    resend_api_key?: StringFilter<"EmailConfig"> | string
    resend_email?: StringFilter<"EmailConfig"> | string
    createdAt?: DateTimeFilter<"EmailConfig"> | Date | string
    updatedAt?: DateTimeFilter<"EmailConfig"> | Date | string
    setting?: XOR<SettingNullableScalarRelationFilter, SettingWhereInput> | null
  }, "id">

  export type EmailConfigOrderByWithAggregationInput = {
    id?: SortOrder
    resend_api_key?: SortOrder
    resend_email?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: EmailConfigCountOrderByAggregateInput
    _max?: EmailConfigMaxOrderByAggregateInput
    _min?: EmailConfigMinOrderByAggregateInput
  }

  export type EmailConfigScalarWhereWithAggregatesInput = {
    AND?: EmailConfigScalarWhereWithAggregatesInput | EmailConfigScalarWhereWithAggregatesInput[]
    OR?: EmailConfigScalarWhereWithAggregatesInput[]
    NOT?: EmailConfigScalarWhereWithAggregatesInput | EmailConfigScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"EmailConfig"> | string
    resend_api_key?: StringWithAggregatesFilter<"EmailConfig"> | string
    resend_email?: StringWithAggregatesFilter<"EmailConfig"> | string
    createdAt?: DateTimeWithAggregatesFilter<"EmailConfig"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"EmailConfig"> | Date | string
  }

  export type CloudConfigWhereInput = {
    AND?: CloudConfigWhereInput | CloudConfigWhereInput[]
    OR?: CloudConfigWhereInput[]
    NOT?: CloudConfigWhereInput | CloudConfigWhereInput[]
    id?: StringFilter<"CloudConfig"> | string
    cloud_name?: StringFilter<"CloudConfig"> | string
    api_key?: StringFilter<"CloudConfig"> | string
    api_secret?: StringFilter<"CloudConfig"> | string
    createdAt?: DateTimeFilter<"CloudConfig"> | Date | string
    updatedAt?: DateTimeFilter<"CloudConfig"> | Date | string
    setting?: XOR<SettingNullableScalarRelationFilter, SettingWhereInput> | null
  }

  export type CloudConfigOrderByWithRelationInput = {
    id?: SortOrder
    cloud_name?: SortOrder
    api_key?: SortOrder
    api_secret?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    setting?: SettingOrderByWithRelationInput
  }

  export type CloudConfigWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: CloudConfigWhereInput | CloudConfigWhereInput[]
    OR?: CloudConfigWhereInput[]
    NOT?: CloudConfigWhereInput | CloudConfigWhereInput[]
    cloud_name?: StringFilter<"CloudConfig"> | string
    api_key?: StringFilter<"CloudConfig"> | string
    api_secret?: StringFilter<"CloudConfig"> | string
    createdAt?: DateTimeFilter<"CloudConfig"> | Date | string
    updatedAt?: DateTimeFilter<"CloudConfig"> | Date | string
    setting?: XOR<SettingNullableScalarRelationFilter, SettingWhereInput> | null
  }, "id">

  export type CloudConfigOrderByWithAggregationInput = {
    id?: SortOrder
    cloud_name?: SortOrder
    api_key?: SortOrder
    api_secret?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: CloudConfigCountOrderByAggregateInput
    _max?: CloudConfigMaxOrderByAggregateInput
    _min?: CloudConfigMinOrderByAggregateInput
  }

  export type CloudConfigScalarWhereWithAggregatesInput = {
    AND?: CloudConfigScalarWhereWithAggregatesInput | CloudConfigScalarWhereWithAggregatesInput[]
    OR?: CloudConfigScalarWhereWithAggregatesInput[]
    NOT?: CloudConfigScalarWhereWithAggregatesInput | CloudConfigScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"CloudConfig"> | string
    cloud_name?: StringWithAggregatesFilter<"CloudConfig"> | string
    api_key?: StringWithAggregatesFilter<"CloudConfig"> | string
    api_secret?: StringWithAggregatesFilter<"CloudConfig"> | string
    createdAt?: DateTimeWithAggregatesFilter<"CloudConfig"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"CloudConfig"> | Date | string
  }

  export type otpWhereInput = {
    AND?: otpWhereInput | otpWhereInput[]
    OR?: otpWhereInput[]
    NOT?: otpWhereInput | otpWhereInput[]
    id?: StringFilter<"otp"> | string
    identifier?: StringFilter<"otp"> | string
    action?: StringFilter<"otp"> | string
    otp?: StringFilter<"otp"> | string
    createdAt?: DateTimeFilter<"otp"> | Date | string
  }

  export type otpOrderByWithRelationInput = {
    id?: SortOrder
    identifier?: SortOrder
    action?: SortOrder
    otp?: SortOrder
    createdAt?: SortOrder
  }

  export type otpWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: otpWhereInput | otpWhereInput[]
    OR?: otpWhereInput[]
    NOT?: otpWhereInput | otpWhereInput[]
    identifier?: StringFilter<"otp"> | string
    action?: StringFilter<"otp"> | string
    otp?: StringFilter<"otp"> | string
    createdAt?: DateTimeFilter<"otp"> | Date | string
  }, "id">

  export type otpOrderByWithAggregationInput = {
    id?: SortOrder
    identifier?: SortOrder
    action?: SortOrder
    otp?: SortOrder
    createdAt?: SortOrder
    _count?: otpCountOrderByAggregateInput
    _max?: otpMaxOrderByAggregateInput
    _min?: otpMinOrderByAggregateInput
  }

  export type otpScalarWhereWithAggregatesInput = {
    AND?: otpScalarWhereWithAggregatesInput | otpScalarWhereWithAggregatesInput[]
    OR?: otpScalarWhereWithAggregatesInput[]
    NOT?: otpScalarWhereWithAggregatesInput | otpScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"otp"> | string
    identifier?: StringWithAggregatesFilter<"otp"> | string
    action?: StringWithAggregatesFilter<"otp"> | string
    otp?: StringWithAggregatesFilter<"otp"> | string
    createdAt?: DateTimeWithAggregatesFilter<"otp"> | Date | string
  }

  export type userCreateInput = {
    id?: string
    name?: string | null
    email: string
    password: string
    image?: string | null
    phone?: string | null
    role: $Enums.Role
    country?: string | null
    city?: string | null
    state?: string | null
    zip_code?: string | null
    address?: string | null
    about?: string | null
    is_deleted?: boolean | null
    otp: string
  }

  export type userUncheckedCreateInput = {
    id?: string
    name?: string | null
    email: string
    password: string
    image?: string | null
    phone?: string | null
    role: $Enums.Role
    country?: string | null
    city?: string | null
    state?: string | null
    zip_code?: string | null
    address?: string | null
    about?: string | null
    is_deleted?: boolean | null
    otp: string
  }

  export type userUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    image?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    country?: NullableStringFieldUpdateOperationsInput | string | null
    city?: NullableStringFieldUpdateOperationsInput | string | null
    state?: NullableStringFieldUpdateOperationsInput | string | null
    zip_code?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    about?: NullableStringFieldUpdateOperationsInput | string | null
    is_deleted?: NullableBoolFieldUpdateOperationsInput | boolean | null
    otp?: StringFieldUpdateOperationsInput | string
  }

  export type userUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    image?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    country?: NullableStringFieldUpdateOperationsInput | string | null
    city?: NullableStringFieldUpdateOperationsInput | string | null
    state?: NullableStringFieldUpdateOperationsInput | string | null
    zip_code?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    about?: NullableStringFieldUpdateOperationsInput | string | null
    is_deleted?: NullableBoolFieldUpdateOperationsInput | boolean | null
    otp?: StringFieldUpdateOperationsInput | string
  }

  export type userCreateManyInput = {
    id?: string
    name?: string | null
    email: string
    password: string
    image?: string | null
    phone?: string | null
    role: $Enums.Role
    country?: string | null
    city?: string | null
    state?: string | null
    zip_code?: string | null
    address?: string | null
    about?: string | null
    is_deleted?: boolean | null
    otp: string
  }

  export type userUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    image?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    country?: NullableStringFieldUpdateOperationsInput | string | null
    city?: NullableStringFieldUpdateOperationsInput | string | null
    state?: NullableStringFieldUpdateOperationsInput | string | null
    zip_code?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    about?: NullableStringFieldUpdateOperationsInput | string | null
    is_deleted?: NullableBoolFieldUpdateOperationsInput | boolean | null
    otp?: StringFieldUpdateOperationsInput | string
  }

  export type userUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    email?: StringFieldUpdateOperationsInput | string
    password?: StringFieldUpdateOperationsInput | string
    image?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    role?: EnumRoleFieldUpdateOperationsInput | $Enums.Role
    country?: NullableStringFieldUpdateOperationsInput | string | null
    city?: NullableStringFieldUpdateOperationsInput | string | null
    state?: NullableStringFieldUpdateOperationsInput | string | null
    zip_code?: NullableStringFieldUpdateOperationsInput | string | null
    address?: NullableStringFieldUpdateOperationsInput | string | null
    about?: NullableStringFieldUpdateOperationsInput | string | null
    is_deleted?: NullableBoolFieldUpdateOperationsInput | boolean | null
    otp?: StringFieldUpdateOperationsInput | string
  }

  export type SettingCreateInput = {
    id?: string
    site_name?: string | null
    site_email?: string | null
    site_phone?: string | null
    site_logo?: string | null
    site_address?: string | null
    site_description?: string | null
    site_footer?: string | null
    client_side_url?: string | null
    server_side_url?: string | null
    otp_verification_type?: string | null
    stripe?: NullableJsonNullValueInput | InputJsonValue
    paypal?: NullableJsonNullValueInput | InputJsonValue
    razorpay?: NullableJsonNullValueInput | InputJsonValue
    mollie?: NullableJsonNullValueInput | InputJsonValue
    social_media_link?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: Date | string
    updatedAt?: Date | string
    email_config?: EmailConfigCreateNestedOneWithoutSettingInput
    cloud_config?: CloudConfigCreateNestedOneWithoutSettingInput
  }

  export type SettingUncheckedCreateInput = {
    id?: string
    site_name?: string | null
    site_email?: string | null
    site_phone?: string | null
    site_logo?: string | null
    site_address?: string | null
    site_description?: string | null
    site_footer?: string | null
    client_side_url?: string | null
    server_side_url?: string | null
    otp_verification_type?: string | null
    email_config_id?: string | null
    cloud_config_id?: string | null
    stripe?: NullableJsonNullValueInput | InputJsonValue
    paypal?: NullableJsonNullValueInput | InputJsonValue
    razorpay?: NullableJsonNullValueInput | InputJsonValue
    mollie?: NullableJsonNullValueInput | InputJsonValue
    social_media_link?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type SettingUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    site_name?: NullableStringFieldUpdateOperationsInput | string | null
    site_email?: NullableStringFieldUpdateOperationsInput | string | null
    site_phone?: NullableStringFieldUpdateOperationsInput | string | null
    site_logo?: NullableStringFieldUpdateOperationsInput | string | null
    site_address?: NullableStringFieldUpdateOperationsInput | string | null
    site_description?: NullableStringFieldUpdateOperationsInput | string | null
    site_footer?: NullableStringFieldUpdateOperationsInput | string | null
    client_side_url?: NullableStringFieldUpdateOperationsInput | string | null
    server_side_url?: NullableStringFieldUpdateOperationsInput | string | null
    otp_verification_type?: NullableStringFieldUpdateOperationsInput | string | null
    stripe?: NullableJsonNullValueInput | InputJsonValue
    paypal?: NullableJsonNullValueInput | InputJsonValue
    razorpay?: NullableJsonNullValueInput | InputJsonValue
    mollie?: NullableJsonNullValueInput | InputJsonValue
    social_media_link?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    email_config?: EmailConfigUpdateOneWithoutSettingNestedInput
    cloud_config?: CloudConfigUpdateOneWithoutSettingNestedInput
  }

  export type SettingUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    site_name?: NullableStringFieldUpdateOperationsInput | string | null
    site_email?: NullableStringFieldUpdateOperationsInput | string | null
    site_phone?: NullableStringFieldUpdateOperationsInput | string | null
    site_logo?: NullableStringFieldUpdateOperationsInput | string | null
    site_address?: NullableStringFieldUpdateOperationsInput | string | null
    site_description?: NullableStringFieldUpdateOperationsInput | string | null
    site_footer?: NullableStringFieldUpdateOperationsInput | string | null
    client_side_url?: NullableStringFieldUpdateOperationsInput | string | null
    server_side_url?: NullableStringFieldUpdateOperationsInput | string | null
    otp_verification_type?: NullableStringFieldUpdateOperationsInput | string | null
    email_config_id?: NullableStringFieldUpdateOperationsInput | string | null
    cloud_config_id?: NullableStringFieldUpdateOperationsInput | string | null
    stripe?: NullableJsonNullValueInput | InputJsonValue
    paypal?: NullableJsonNullValueInput | InputJsonValue
    razorpay?: NullableJsonNullValueInput | InputJsonValue
    mollie?: NullableJsonNullValueInput | InputJsonValue
    social_media_link?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SettingCreateManyInput = {
    id?: string
    site_name?: string | null
    site_email?: string | null
    site_phone?: string | null
    site_logo?: string | null
    site_address?: string | null
    site_description?: string | null
    site_footer?: string | null
    client_side_url?: string | null
    server_side_url?: string | null
    otp_verification_type?: string | null
    email_config_id?: string | null
    cloud_config_id?: string | null
    stripe?: NullableJsonNullValueInput | InputJsonValue
    paypal?: NullableJsonNullValueInput | InputJsonValue
    razorpay?: NullableJsonNullValueInput | InputJsonValue
    mollie?: NullableJsonNullValueInput | InputJsonValue
    social_media_link?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type SettingUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    site_name?: NullableStringFieldUpdateOperationsInput | string | null
    site_email?: NullableStringFieldUpdateOperationsInput | string | null
    site_phone?: NullableStringFieldUpdateOperationsInput | string | null
    site_logo?: NullableStringFieldUpdateOperationsInput | string | null
    site_address?: NullableStringFieldUpdateOperationsInput | string | null
    site_description?: NullableStringFieldUpdateOperationsInput | string | null
    site_footer?: NullableStringFieldUpdateOperationsInput | string | null
    client_side_url?: NullableStringFieldUpdateOperationsInput | string | null
    server_side_url?: NullableStringFieldUpdateOperationsInput | string | null
    otp_verification_type?: NullableStringFieldUpdateOperationsInput | string | null
    stripe?: NullableJsonNullValueInput | InputJsonValue
    paypal?: NullableJsonNullValueInput | InputJsonValue
    razorpay?: NullableJsonNullValueInput | InputJsonValue
    mollie?: NullableJsonNullValueInput | InputJsonValue
    social_media_link?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SettingUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    site_name?: NullableStringFieldUpdateOperationsInput | string | null
    site_email?: NullableStringFieldUpdateOperationsInput | string | null
    site_phone?: NullableStringFieldUpdateOperationsInput | string | null
    site_logo?: NullableStringFieldUpdateOperationsInput | string | null
    site_address?: NullableStringFieldUpdateOperationsInput | string | null
    site_description?: NullableStringFieldUpdateOperationsInput | string | null
    site_footer?: NullableStringFieldUpdateOperationsInput | string | null
    client_side_url?: NullableStringFieldUpdateOperationsInput | string | null
    server_side_url?: NullableStringFieldUpdateOperationsInput | string | null
    otp_verification_type?: NullableStringFieldUpdateOperationsInput | string | null
    email_config_id?: NullableStringFieldUpdateOperationsInput | string | null
    cloud_config_id?: NullableStringFieldUpdateOperationsInput | string | null
    stripe?: NullableJsonNullValueInput | InputJsonValue
    paypal?: NullableJsonNullValueInput | InputJsonValue
    razorpay?: NullableJsonNullValueInput | InputJsonValue
    mollie?: NullableJsonNullValueInput | InputJsonValue
    social_media_link?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type EmailConfigCreateInput = {
    id?: string
    resend_api_key: string
    resend_email: string
    createdAt?: Date | string
    updatedAt?: Date | string
    setting?: SettingCreateNestedOneWithoutEmail_configInput
  }

  export type EmailConfigUncheckedCreateInput = {
    id?: string
    resend_api_key: string
    resend_email: string
    createdAt?: Date | string
    updatedAt?: Date | string
    setting?: SettingUncheckedCreateNestedOneWithoutEmail_configInput
  }

  export type EmailConfigUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    resend_api_key?: StringFieldUpdateOperationsInput | string
    resend_email?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    setting?: SettingUpdateOneWithoutEmail_configNestedInput
  }

  export type EmailConfigUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    resend_api_key?: StringFieldUpdateOperationsInput | string
    resend_email?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    setting?: SettingUncheckedUpdateOneWithoutEmail_configNestedInput
  }

  export type EmailConfigCreateManyInput = {
    id?: string
    resend_api_key: string
    resend_email: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type EmailConfigUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    resend_api_key?: StringFieldUpdateOperationsInput | string
    resend_email?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type EmailConfigUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    resend_api_key?: StringFieldUpdateOperationsInput | string
    resend_email?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type CloudConfigCreateInput = {
    id?: string
    cloud_name: string
    api_key: string
    api_secret: string
    createdAt?: Date | string
    updatedAt?: Date | string
    setting?: SettingCreateNestedOneWithoutCloud_configInput
  }

  export type CloudConfigUncheckedCreateInput = {
    id?: string
    cloud_name: string
    api_key: string
    api_secret: string
    createdAt?: Date | string
    updatedAt?: Date | string
    setting?: SettingUncheckedCreateNestedOneWithoutCloud_configInput
  }

  export type CloudConfigUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    cloud_name?: StringFieldUpdateOperationsInput | string
    api_key?: StringFieldUpdateOperationsInput | string
    api_secret?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    setting?: SettingUpdateOneWithoutCloud_configNestedInput
  }

  export type CloudConfigUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    cloud_name?: StringFieldUpdateOperationsInput | string
    api_key?: StringFieldUpdateOperationsInput | string
    api_secret?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    setting?: SettingUncheckedUpdateOneWithoutCloud_configNestedInput
  }

  export type CloudConfigCreateManyInput = {
    id?: string
    cloud_name: string
    api_key: string
    api_secret: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type CloudConfigUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    cloud_name?: StringFieldUpdateOperationsInput | string
    api_key?: StringFieldUpdateOperationsInput | string
    api_secret?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type CloudConfigUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    cloud_name?: StringFieldUpdateOperationsInput | string
    api_key?: StringFieldUpdateOperationsInput | string
    api_secret?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type otpCreateInput = {
    id?: string
    identifier: string
    action: string
    otp: string
    createdAt?: Date | string
  }

  export type otpUncheckedCreateInput = {
    id?: string
    identifier: string
    action: string
    otp: string
    createdAt?: Date | string
  }

  export type otpUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    identifier?: StringFieldUpdateOperationsInput | string
    action?: StringFieldUpdateOperationsInput | string
    otp?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type otpUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    identifier?: StringFieldUpdateOperationsInput | string
    action?: StringFieldUpdateOperationsInput | string
    otp?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type otpCreateManyInput = {
    id?: string
    identifier: string
    action: string
    otp: string
    createdAt?: Date | string
  }

  export type otpUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    identifier?: StringFieldUpdateOperationsInput | string
    action?: StringFieldUpdateOperationsInput | string
    otp?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type otpUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    identifier?: StringFieldUpdateOperationsInput | string
    action?: StringFieldUpdateOperationsInput | string
    otp?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type StringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type StringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type EnumRoleFilter<$PrismaModel = never> = {
    equals?: $Enums.Role | EnumRoleFieldRefInput<$PrismaModel>
    in?: $Enums.Role[] | ListEnumRoleFieldRefInput<$PrismaModel>
    notIn?: $Enums.Role[] | ListEnumRoleFieldRefInput<$PrismaModel>
    not?: NestedEnumRoleFilter<$PrismaModel> | $Enums.Role
  }

  export type BoolNullableFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel> | null
    not?: NestedBoolNullableFilter<$PrismaModel> | boolean | null
  }

  export type SortOrderInput = {
    sort: SortOrder
    nulls?: NullsOrder
  }

  export type userCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    email?: SortOrder
    password?: SortOrder
    image?: SortOrder
    phone?: SortOrder
    role?: SortOrder
    country?: SortOrder
    city?: SortOrder
    state?: SortOrder
    zip_code?: SortOrder
    address?: SortOrder
    about?: SortOrder
    is_deleted?: SortOrder
    otp?: SortOrder
  }

  export type userMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    email?: SortOrder
    password?: SortOrder
    image?: SortOrder
    phone?: SortOrder
    role?: SortOrder
    country?: SortOrder
    city?: SortOrder
    state?: SortOrder
    zip_code?: SortOrder
    address?: SortOrder
    about?: SortOrder
    is_deleted?: SortOrder
    otp?: SortOrder
  }

  export type userMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    email?: SortOrder
    password?: SortOrder
    image?: SortOrder
    phone?: SortOrder
    role?: SortOrder
    country?: SortOrder
    city?: SortOrder
    state?: SortOrder
    zip_code?: SortOrder
    address?: SortOrder
    about?: SortOrder
    is_deleted?: SortOrder
    otp?: SortOrder
  }

  export type StringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type StringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type EnumRoleWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.Role | EnumRoleFieldRefInput<$PrismaModel>
    in?: $Enums.Role[] | ListEnumRoleFieldRefInput<$PrismaModel>
    notIn?: $Enums.Role[] | ListEnumRoleFieldRefInput<$PrismaModel>
    not?: NestedEnumRoleWithAggregatesFilter<$PrismaModel> | $Enums.Role
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumRoleFilter<$PrismaModel>
    _max?: NestedEnumRoleFilter<$PrismaModel>
  }

  export type BoolNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel> | null
    not?: NestedBoolNullableWithAggregatesFilter<$PrismaModel> | boolean | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedBoolNullableFilter<$PrismaModel>
    _max?: NestedBoolNullableFilter<$PrismaModel>
  }
  export type JsonNullableFilter<$PrismaModel = never> =
    | PatchUndefined<
        Either<Required<JsonNullableFilterBase<$PrismaModel>>, Exclude<keyof Required<JsonNullableFilterBase<$PrismaModel>>, 'path'>>,
        Required<JsonNullableFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<JsonNullableFilterBase<$PrismaModel>>, 'path'>>

  export type JsonNullableFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string[]
    mode?: QueryMode | EnumQueryModeFieldRefInput<$PrismaModel>
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    lte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
  }

  export type DateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type EmailConfigNullableScalarRelationFilter = {
    is?: EmailConfigWhereInput | null
    isNot?: EmailConfigWhereInput | null
  }

  export type CloudConfigNullableScalarRelationFilter = {
    is?: CloudConfigWhereInput | null
    isNot?: CloudConfigWhereInput | null
  }

  export type SettingCountOrderByAggregateInput = {
    id?: SortOrder
    site_name?: SortOrder
    site_email?: SortOrder
    site_phone?: SortOrder
    site_logo?: SortOrder
    site_address?: SortOrder
    site_description?: SortOrder
    site_footer?: SortOrder
    client_side_url?: SortOrder
    server_side_url?: SortOrder
    otp_verification_type?: SortOrder
    email_config_id?: SortOrder
    cloud_config_id?: SortOrder
    stripe?: SortOrder
    paypal?: SortOrder
    razorpay?: SortOrder
    mollie?: SortOrder
    social_media_link?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SettingMaxOrderByAggregateInput = {
    id?: SortOrder
    site_name?: SortOrder
    site_email?: SortOrder
    site_phone?: SortOrder
    site_logo?: SortOrder
    site_address?: SortOrder
    site_description?: SortOrder
    site_footer?: SortOrder
    client_side_url?: SortOrder
    server_side_url?: SortOrder
    otp_verification_type?: SortOrder
    email_config_id?: SortOrder
    cloud_config_id?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SettingMinOrderByAggregateInput = {
    id?: SortOrder
    site_name?: SortOrder
    site_email?: SortOrder
    site_phone?: SortOrder
    site_logo?: SortOrder
    site_address?: SortOrder
    site_description?: SortOrder
    site_footer?: SortOrder
    client_side_url?: SortOrder
    server_side_url?: SortOrder
    otp_verification_type?: SortOrder
    email_config_id?: SortOrder
    cloud_config_id?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }
  export type JsonNullableWithAggregatesFilter<$PrismaModel = never> =
    | PatchUndefined<
        Either<Required<JsonNullableWithAggregatesFilterBase<$PrismaModel>>, Exclude<keyof Required<JsonNullableWithAggregatesFilterBase<$PrismaModel>>, 'path'>>,
        Required<JsonNullableWithAggregatesFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<JsonNullableWithAggregatesFilterBase<$PrismaModel>>, 'path'>>

  export type JsonNullableWithAggregatesFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string[]
    mode?: QueryMode | EnumQueryModeFieldRefInput<$PrismaModel>
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    lte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedJsonNullableFilter<$PrismaModel>
    _max?: NestedJsonNullableFilter<$PrismaModel>
  }

  export type DateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type SettingNullableScalarRelationFilter = {
    is?: SettingWhereInput | null
    isNot?: SettingWhereInput | null
  }

  export type EmailConfigCountOrderByAggregateInput = {
    id?: SortOrder
    resend_api_key?: SortOrder
    resend_email?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type EmailConfigMaxOrderByAggregateInput = {
    id?: SortOrder
    resend_api_key?: SortOrder
    resend_email?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type EmailConfigMinOrderByAggregateInput = {
    id?: SortOrder
    resend_api_key?: SortOrder
    resend_email?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type CloudConfigCountOrderByAggregateInput = {
    id?: SortOrder
    cloud_name?: SortOrder
    api_key?: SortOrder
    api_secret?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type CloudConfigMaxOrderByAggregateInput = {
    id?: SortOrder
    cloud_name?: SortOrder
    api_key?: SortOrder
    api_secret?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type CloudConfigMinOrderByAggregateInput = {
    id?: SortOrder
    cloud_name?: SortOrder
    api_key?: SortOrder
    api_secret?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type otpCountOrderByAggregateInput = {
    id?: SortOrder
    identifier?: SortOrder
    action?: SortOrder
    otp?: SortOrder
    createdAt?: SortOrder
  }

  export type otpMaxOrderByAggregateInput = {
    id?: SortOrder
    identifier?: SortOrder
    action?: SortOrder
    otp?: SortOrder
    createdAt?: SortOrder
  }

  export type otpMinOrderByAggregateInput = {
    id?: SortOrder
    identifier?: SortOrder
    action?: SortOrder
    otp?: SortOrder
    createdAt?: SortOrder
  }

  export type StringFieldUpdateOperationsInput = {
    set?: string
  }

  export type NullableStringFieldUpdateOperationsInput = {
    set?: string | null
  }

  export type EnumRoleFieldUpdateOperationsInput = {
    set?: $Enums.Role
  }

  export type NullableBoolFieldUpdateOperationsInput = {
    set?: boolean | null
  }

  export type EmailConfigCreateNestedOneWithoutSettingInput = {
    create?: XOR<EmailConfigCreateWithoutSettingInput, EmailConfigUncheckedCreateWithoutSettingInput>
    connectOrCreate?: EmailConfigCreateOrConnectWithoutSettingInput
    connect?: EmailConfigWhereUniqueInput
  }

  export type CloudConfigCreateNestedOneWithoutSettingInput = {
    create?: XOR<CloudConfigCreateWithoutSettingInput, CloudConfigUncheckedCreateWithoutSettingInput>
    connectOrCreate?: CloudConfigCreateOrConnectWithoutSettingInput
    connect?: CloudConfigWhereUniqueInput
  }

  export type DateTimeFieldUpdateOperationsInput = {
    set?: Date | string
  }

  export type EmailConfigUpdateOneWithoutSettingNestedInput = {
    create?: XOR<EmailConfigCreateWithoutSettingInput, EmailConfigUncheckedCreateWithoutSettingInput>
    connectOrCreate?: EmailConfigCreateOrConnectWithoutSettingInput
    upsert?: EmailConfigUpsertWithoutSettingInput
    disconnect?: EmailConfigWhereInput | boolean
    delete?: EmailConfigWhereInput | boolean
    connect?: EmailConfigWhereUniqueInput
    update?: XOR<XOR<EmailConfigUpdateToOneWithWhereWithoutSettingInput, EmailConfigUpdateWithoutSettingInput>, EmailConfigUncheckedUpdateWithoutSettingInput>
  }

  export type CloudConfigUpdateOneWithoutSettingNestedInput = {
    create?: XOR<CloudConfigCreateWithoutSettingInput, CloudConfigUncheckedCreateWithoutSettingInput>
    connectOrCreate?: CloudConfigCreateOrConnectWithoutSettingInput
    upsert?: CloudConfigUpsertWithoutSettingInput
    disconnect?: CloudConfigWhereInput | boolean
    delete?: CloudConfigWhereInput | boolean
    connect?: CloudConfigWhereUniqueInput
    update?: XOR<XOR<CloudConfigUpdateToOneWithWhereWithoutSettingInput, CloudConfigUpdateWithoutSettingInput>, CloudConfigUncheckedUpdateWithoutSettingInput>
  }

  export type SettingCreateNestedOneWithoutEmail_configInput = {
    create?: XOR<SettingCreateWithoutEmail_configInput, SettingUncheckedCreateWithoutEmail_configInput>
    connectOrCreate?: SettingCreateOrConnectWithoutEmail_configInput
    connect?: SettingWhereUniqueInput
  }

  export type SettingUncheckedCreateNestedOneWithoutEmail_configInput = {
    create?: XOR<SettingCreateWithoutEmail_configInput, SettingUncheckedCreateWithoutEmail_configInput>
    connectOrCreate?: SettingCreateOrConnectWithoutEmail_configInput
    connect?: SettingWhereUniqueInput
  }

  export type SettingUpdateOneWithoutEmail_configNestedInput = {
    create?: XOR<SettingCreateWithoutEmail_configInput, SettingUncheckedCreateWithoutEmail_configInput>
    connectOrCreate?: SettingCreateOrConnectWithoutEmail_configInput
    upsert?: SettingUpsertWithoutEmail_configInput
    disconnect?: SettingWhereInput | boolean
    delete?: SettingWhereInput | boolean
    connect?: SettingWhereUniqueInput
    update?: XOR<XOR<SettingUpdateToOneWithWhereWithoutEmail_configInput, SettingUpdateWithoutEmail_configInput>, SettingUncheckedUpdateWithoutEmail_configInput>
  }

  export type SettingUncheckedUpdateOneWithoutEmail_configNestedInput = {
    create?: XOR<SettingCreateWithoutEmail_configInput, SettingUncheckedCreateWithoutEmail_configInput>
    connectOrCreate?: SettingCreateOrConnectWithoutEmail_configInput
    upsert?: SettingUpsertWithoutEmail_configInput
    disconnect?: SettingWhereInput | boolean
    delete?: SettingWhereInput | boolean
    connect?: SettingWhereUniqueInput
    update?: XOR<XOR<SettingUpdateToOneWithWhereWithoutEmail_configInput, SettingUpdateWithoutEmail_configInput>, SettingUncheckedUpdateWithoutEmail_configInput>
  }

  export type SettingCreateNestedOneWithoutCloud_configInput = {
    create?: XOR<SettingCreateWithoutCloud_configInput, SettingUncheckedCreateWithoutCloud_configInput>
    connectOrCreate?: SettingCreateOrConnectWithoutCloud_configInput
    connect?: SettingWhereUniqueInput
  }

  export type SettingUncheckedCreateNestedOneWithoutCloud_configInput = {
    create?: XOR<SettingCreateWithoutCloud_configInput, SettingUncheckedCreateWithoutCloud_configInput>
    connectOrCreate?: SettingCreateOrConnectWithoutCloud_configInput
    connect?: SettingWhereUniqueInput
  }

  export type SettingUpdateOneWithoutCloud_configNestedInput = {
    create?: XOR<SettingCreateWithoutCloud_configInput, SettingUncheckedCreateWithoutCloud_configInput>
    connectOrCreate?: SettingCreateOrConnectWithoutCloud_configInput
    upsert?: SettingUpsertWithoutCloud_configInput
    disconnect?: SettingWhereInput | boolean
    delete?: SettingWhereInput | boolean
    connect?: SettingWhereUniqueInput
    update?: XOR<XOR<SettingUpdateToOneWithWhereWithoutCloud_configInput, SettingUpdateWithoutCloud_configInput>, SettingUncheckedUpdateWithoutCloud_configInput>
  }

  export type SettingUncheckedUpdateOneWithoutCloud_configNestedInput = {
    create?: XOR<SettingCreateWithoutCloud_configInput, SettingUncheckedCreateWithoutCloud_configInput>
    connectOrCreate?: SettingCreateOrConnectWithoutCloud_configInput
    upsert?: SettingUpsertWithoutCloud_configInput
    disconnect?: SettingWhereInput | boolean
    delete?: SettingWhereInput | boolean
    connect?: SettingWhereUniqueInput
    update?: XOR<XOR<SettingUpdateToOneWithWhereWithoutCloud_configInput, SettingUpdateWithoutCloud_configInput>, SettingUncheckedUpdateWithoutCloud_configInput>
  }

  export type NestedStringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type NestedStringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type NestedEnumRoleFilter<$PrismaModel = never> = {
    equals?: $Enums.Role | EnumRoleFieldRefInput<$PrismaModel>
    in?: $Enums.Role[] | ListEnumRoleFieldRefInput<$PrismaModel>
    notIn?: $Enums.Role[] | ListEnumRoleFieldRefInput<$PrismaModel>
    not?: NestedEnumRoleFilter<$PrismaModel> | $Enums.Role
  }

  export type NestedBoolNullableFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel> | null
    not?: NestedBoolNullableFilter<$PrismaModel> | boolean | null
  }

  export type NestedStringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type NestedIntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type NestedStringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type NestedIntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type NestedEnumRoleWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.Role | EnumRoleFieldRefInput<$PrismaModel>
    in?: $Enums.Role[] | ListEnumRoleFieldRefInput<$PrismaModel>
    notIn?: $Enums.Role[] | ListEnumRoleFieldRefInput<$PrismaModel>
    not?: NestedEnumRoleWithAggregatesFilter<$PrismaModel> | $Enums.Role
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumRoleFilter<$PrismaModel>
    _max?: NestedEnumRoleFilter<$PrismaModel>
  }

  export type NestedBoolNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel> | null
    not?: NestedBoolNullableWithAggregatesFilter<$PrismaModel> | boolean | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedBoolNullableFilter<$PrismaModel>
    _max?: NestedBoolNullableFilter<$PrismaModel>
  }

  export type NestedDateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }
  export type NestedJsonNullableFilter<$PrismaModel = never> =
    | PatchUndefined<
        Either<Required<NestedJsonNullableFilterBase<$PrismaModel>>, Exclude<keyof Required<NestedJsonNullableFilterBase<$PrismaModel>>, 'path'>>,
        Required<NestedJsonNullableFilterBase<$PrismaModel>>
      >
    | OptionalFlat<Omit<Required<NestedJsonNullableFilterBase<$PrismaModel>>, 'path'>>

  export type NestedJsonNullableFilterBase<$PrismaModel = never> = {
    equals?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
    path?: string[]
    mode?: QueryMode | EnumQueryModeFieldRefInput<$PrismaModel>
    string_contains?: string | StringFieldRefInput<$PrismaModel>
    string_starts_with?: string | StringFieldRefInput<$PrismaModel>
    string_ends_with?: string | StringFieldRefInput<$PrismaModel>
    array_starts_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_ends_with?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    array_contains?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | null
    lt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    lte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gt?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    gte?: InputJsonValue | JsonFieldRefInput<$PrismaModel>
    not?: InputJsonValue | JsonFieldRefInput<$PrismaModel> | JsonNullValueFilter
  }

  export type NestedDateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type EmailConfigCreateWithoutSettingInput = {
    id?: string
    resend_api_key: string
    resend_email: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type EmailConfigUncheckedCreateWithoutSettingInput = {
    id?: string
    resend_api_key: string
    resend_email: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type EmailConfigCreateOrConnectWithoutSettingInput = {
    where: EmailConfigWhereUniqueInput
    create: XOR<EmailConfigCreateWithoutSettingInput, EmailConfigUncheckedCreateWithoutSettingInput>
  }

  export type CloudConfigCreateWithoutSettingInput = {
    id?: string
    cloud_name: string
    api_key: string
    api_secret: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type CloudConfigUncheckedCreateWithoutSettingInput = {
    id?: string
    cloud_name: string
    api_key: string
    api_secret: string
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type CloudConfigCreateOrConnectWithoutSettingInput = {
    where: CloudConfigWhereUniqueInput
    create: XOR<CloudConfigCreateWithoutSettingInput, CloudConfigUncheckedCreateWithoutSettingInput>
  }

  export type EmailConfigUpsertWithoutSettingInput = {
    update: XOR<EmailConfigUpdateWithoutSettingInput, EmailConfigUncheckedUpdateWithoutSettingInput>
    create: XOR<EmailConfigCreateWithoutSettingInput, EmailConfigUncheckedCreateWithoutSettingInput>
    where?: EmailConfigWhereInput
  }

  export type EmailConfigUpdateToOneWithWhereWithoutSettingInput = {
    where?: EmailConfigWhereInput
    data: XOR<EmailConfigUpdateWithoutSettingInput, EmailConfigUncheckedUpdateWithoutSettingInput>
  }

  export type EmailConfigUpdateWithoutSettingInput = {
    id?: StringFieldUpdateOperationsInput | string
    resend_api_key?: StringFieldUpdateOperationsInput | string
    resend_email?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type EmailConfigUncheckedUpdateWithoutSettingInput = {
    id?: StringFieldUpdateOperationsInput | string
    resend_api_key?: StringFieldUpdateOperationsInput | string
    resend_email?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type CloudConfigUpsertWithoutSettingInput = {
    update: XOR<CloudConfigUpdateWithoutSettingInput, CloudConfigUncheckedUpdateWithoutSettingInput>
    create: XOR<CloudConfigCreateWithoutSettingInput, CloudConfigUncheckedCreateWithoutSettingInput>
    where?: CloudConfigWhereInput
  }

  export type CloudConfigUpdateToOneWithWhereWithoutSettingInput = {
    where?: CloudConfigWhereInput
    data: XOR<CloudConfigUpdateWithoutSettingInput, CloudConfigUncheckedUpdateWithoutSettingInput>
  }

  export type CloudConfigUpdateWithoutSettingInput = {
    id?: StringFieldUpdateOperationsInput | string
    cloud_name?: StringFieldUpdateOperationsInput | string
    api_key?: StringFieldUpdateOperationsInput | string
    api_secret?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type CloudConfigUncheckedUpdateWithoutSettingInput = {
    id?: StringFieldUpdateOperationsInput | string
    cloud_name?: StringFieldUpdateOperationsInput | string
    api_key?: StringFieldUpdateOperationsInput | string
    api_secret?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SettingCreateWithoutEmail_configInput = {
    id?: string
    site_name?: string | null
    site_email?: string | null
    site_phone?: string | null
    site_logo?: string | null
    site_address?: string | null
    site_description?: string | null
    site_footer?: string | null
    client_side_url?: string | null
    server_side_url?: string | null
    otp_verification_type?: string | null
    stripe?: NullableJsonNullValueInput | InputJsonValue
    paypal?: NullableJsonNullValueInput | InputJsonValue
    razorpay?: NullableJsonNullValueInput | InputJsonValue
    mollie?: NullableJsonNullValueInput | InputJsonValue
    social_media_link?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: Date | string
    updatedAt?: Date | string
    cloud_config?: CloudConfigCreateNestedOneWithoutSettingInput
  }

  export type SettingUncheckedCreateWithoutEmail_configInput = {
    id?: string
    site_name?: string | null
    site_email?: string | null
    site_phone?: string | null
    site_logo?: string | null
    site_address?: string | null
    site_description?: string | null
    site_footer?: string | null
    client_side_url?: string | null
    server_side_url?: string | null
    otp_verification_type?: string | null
    cloud_config_id?: string | null
    stripe?: NullableJsonNullValueInput | InputJsonValue
    paypal?: NullableJsonNullValueInput | InputJsonValue
    razorpay?: NullableJsonNullValueInput | InputJsonValue
    mollie?: NullableJsonNullValueInput | InputJsonValue
    social_media_link?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type SettingCreateOrConnectWithoutEmail_configInput = {
    where: SettingWhereUniqueInput
    create: XOR<SettingCreateWithoutEmail_configInput, SettingUncheckedCreateWithoutEmail_configInput>
  }

  export type SettingUpsertWithoutEmail_configInput = {
    update: XOR<SettingUpdateWithoutEmail_configInput, SettingUncheckedUpdateWithoutEmail_configInput>
    create: XOR<SettingCreateWithoutEmail_configInput, SettingUncheckedCreateWithoutEmail_configInput>
    where?: SettingWhereInput
  }

  export type SettingUpdateToOneWithWhereWithoutEmail_configInput = {
    where?: SettingWhereInput
    data: XOR<SettingUpdateWithoutEmail_configInput, SettingUncheckedUpdateWithoutEmail_configInput>
  }

  export type SettingUpdateWithoutEmail_configInput = {
    id?: StringFieldUpdateOperationsInput | string
    site_name?: NullableStringFieldUpdateOperationsInput | string | null
    site_email?: NullableStringFieldUpdateOperationsInput | string | null
    site_phone?: NullableStringFieldUpdateOperationsInput | string | null
    site_logo?: NullableStringFieldUpdateOperationsInput | string | null
    site_address?: NullableStringFieldUpdateOperationsInput | string | null
    site_description?: NullableStringFieldUpdateOperationsInput | string | null
    site_footer?: NullableStringFieldUpdateOperationsInput | string | null
    client_side_url?: NullableStringFieldUpdateOperationsInput | string | null
    server_side_url?: NullableStringFieldUpdateOperationsInput | string | null
    otp_verification_type?: NullableStringFieldUpdateOperationsInput | string | null
    stripe?: NullableJsonNullValueInput | InputJsonValue
    paypal?: NullableJsonNullValueInput | InputJsonValue
    razorpay?: NullableJsonNullValueInput | InputJsonValue
    mollie?: NullableJsonNullValueInput | InputJsonValue
    social_media_link?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    cloud_config?: CloudConfigUpdateOneWithoutSettingNestedInput
  }

  export type SettingUncheckedUpdateWithoutEmail_configInput = {
    id?: StringFieldUpdateOperationsInput | string
    site_name?: NullableStringFieldUpdateOperationsInput | string | null
    site_email?: NullableStringFieldUpdateOperationsInput | string | null
    site_phone?: NullableStringFieldUpdateOperationsInput | string | null
    site_logo?: NullableStringFieldUpdateOperationsInput | string | null
    site_address?: NullableStringFieldUpdateOperationsInput | string | null
    site_description?: NullableStringFieldUpdateOperationsInput | string | null
    site_footer?: NullableStringFieldUpdateOperationsInput | string | null
    client_side_url?: NullableStringFieldUpdateOperationsInput | string | null
    server_side_url?: NullableStringFieldUpdateOperationsInput | string | null
    otp_verification_type?: NullableStringFieldUpdateOperationsInput | string | null
    cloud_config_id?: NullableStringFieldUpdateOperationsInput | string | null
    stripe?: NullableJsonNullValueInput | InputJsonValue
    paypal?: NullableJsonNullValueInput | InputJsonValue
    razorpay?: NullableJsonNullValueInput | InputJsonValue
    mollie?: NullableJsonNullValueInput | InputJsonValue
    social_media_link?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SettingCreateWithoutCloud_configInput = {
    id?: string
    site_name?: string | null
    site_email?: string | null
    site_phone?: string | null
    site_logo?: string | null
    site_address?: string | null
    site_description?: string | null
    site_footer?: string | null
    client_side_url?: string | null
    server_side_url?: string | null
    otp_verification_type?: string | null
    stripe?: NullableJsonNullValueInput | InputJsonValue
    paypal?: NullableJsonNullValueInput | InputJsonValue
    razorpay?: NullableJsonNullValueInput | InputJsonValue
    mollie?: NullableJsonNullValueInput | InputJsonValue
    social_media_link?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: Date | string
    updatedAt?: Date | string
    email_config?: EmailConfigCreateNestedOneWithoutSettingInput
  }

  export type SettingUncheckedCreateWithoutCloud_configInput = {
    id?: string
    site_name?: string | null
    site_email?: string | null
    site_phone?: string | null
    site_logo?: string | null
    site_address?: string | null
    site_description?: string | null
    site_footer?: string | null
    client_side_url?: string | null
    server_side_url?: string | null
    otp_verification_type?: string | null
    email_config_id?: string | null
    stripe?: NullableJsonNullValueInput | InputJsonValue
    paypal?: NullableJsonNullValueInput | InputJsonValue
    razorpay?: NullableJsonNullValueInput | InputJsonValue
    mollie?: NullableJsonNullValueInput | InputJsonValue
    social_media_link?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type SettingCreateOrConnectWithoutCloud_configInput = {
    where: SettingWhereUniqueInput
    create: XOR<SettingCreateWithoutCloud_configInput, SettingUncheckedCreateWithoutCloud_configInput>
  }

  export type SettingUpsertWithoutCloud_configInput = {
    update: XOR<SettingUpdateWithoutCloud_configInput, SettingUncheckedUpdateWithoutCloud_configInput>
    create: XOR<SettingCreateWithoutCloud_configInput, SettingUncheckedCreateWithoutCloud_configInput>
    where?: SettingWhereInput
  }

  export type SettingUpdateToOneWithWhereWithoutCloud_configInput = {
    where?: SettingWhereInput
    data: XOR<SettingUpdateWithoutCloud_configInput, SettingUncheckedUpdateWithoutCloud_configInput>
  }

  export type SettingUpdateWithoutCloud_configInput = {
    id?: StringFieldUpdateOperationsInput | string
    site_name?: NullableStringFieldUpdateOperationsInput | string | null
    site_email?: NullableStringFieldUpdateOperationsInput | string | null
    site_phone?: NullableStringFieldUpdateOperationsInput | string | null
    site_logo?: NullableStringFieldUpdateOperationsInput | string | null
    site_address?: NullableStringFieldUpdateOperationsInput | string | null
    site_description?: NullableStringFieldUpdateOperationsInput | string | null
    site_footer?: NullableStringFieldUpdateOperationsInput | string | null
    client_side_url?: NullableStringFieldUpdateOperationsInput | string | null
    server_side_url?: NullableStringFieldUpdateOperationsInput | string | null
    otp_verification_type?: NullableStringFieldUpdateOperationsInput | string | null
    stripe?: NullableJsonNullValueInput | InputJsonValue
    paypal?: NullableJsonNullValueInput | InputJsonValue
    razorpay?: NullableJsonNullValueInput | InputJsonValue
    mollie?: NullableJsonNullValueInput | InputJsonValue
    social_media_link?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    email_config?: EmailConfigUpdateOneWithoutSettingNestedInput
  }

  export type SettingUncheckedUpdateWithoutCloud_configInput = {
    id?: StringFieldUpdateOperationsInput | string
    site_name?: NullableStringFieldUpdateOperationsInput | string | null
    site_email?: NullableStringFieldUpdateOperationsInput | string | null
    site_phone?: NullableStringFieldUpdateOperationsInput | string | null
    site_logo?: NullableStringFieldUpdateOperationsInput | string | null
    site_address?: NullableStringFieldUpdateOperationsInput | string | null
    site_description?: NullableStringFieldUpdateOperationsInput | string | null
    site_footer?: NullableStringFieldUpdateOperationsInput | string | null
    client_side_url?: NullableStringFieldUpdateOperationsInput | string | null
    server_side_url?: NullableStringFieldUpdateOperationsInput | string | null
    otp_verification_type?: NullableStringFieldUpdateOperationsInput | string | null
    email_config_id?: NullableStringFieldUpdateOperationsInput | string | null
    stripe?: NullableJsonNullValueInput | InputJsonValue
    paypal?: NullableJsonNullValueInput | InputJsonValue
    razorpay?: NullableJsonNullValueInput | InputJsonValue
    mollie?: NullableJsonNullValueInput | InputJsonValue
    social_media_link?: NullableJsonNullValueInput | InputJsonValue
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }



  /**
   * Batch Payload for updateMany & deleteMany & createMany
   */

  export type BatchPayload = {
    count: number
  }

  /**
   * DMMF
   */
  export const dmmf: runtime.BaseDMMF
}