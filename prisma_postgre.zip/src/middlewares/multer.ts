import { NextFunction, Request, Response } from "express";
import multer from "multer";
import path from "path";
import { fileURLToPath } from "url";


const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
console.log("__dirname",path.join(__dirname, "../../public/tmp"));
const storage = multer.diskStorage({
 
  destination: function (req, file, cb) {
    cb(null, path.join(__dirname, "../../public/tmp"));
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + "-" + file.originalname);
  },
});

const upload = multer({ storage });

// ✅ conditional middleware
const conditionalUpload = (req:Request, res:Response, next:NextFunction) => {
  const contentType = req.headers["content-type"] || "";

  // যদি multipart/form-data হয়, তাহলে multer চালাও
  if (contentType.startsWith("multipart/form-data")) {
    return upload.single("image")(req, res, (err) => {
      if (err) {
        console.error("Multer error:", err);
        return res.status(400).json({ message: "File upload error" });
      }
      next();
    });
  }

  // অন্যথায় সরাসরি next()
  next();
};

export { conditionalUpload };
