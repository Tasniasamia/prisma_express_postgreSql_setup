import { Request, Response } from "express";

const auth=async(req:Request,res:Response)=>{
 console.log("cookies")
}